<?php
session_start();
include("database.php");
if(isset($_SESSION['login']))
{
	if(isset($_POST['submit']))
	{
		$sub=$_POST['submit'];
		if($sub=='Finish')
		{
			//mysql_query("delete from mst_useranswer where sess_id='" . session_id() ."'") or die(mysql_error());
				unset($_SESSION['qn']);
				unset($_SESSION['sid']);
				unset($_SESSION['tid']);
				unset($_SESSION['trueans']);
				unset($_SESSION['q_arr']);
				unset($_SESSION['level']);
				header("Location: login.php");
				exit;
		}
	}
?>
				
				

<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html class=" js flexbox canvas canvastext no-webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms no-csstransforms3d csstransitions fontface video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths cufon-active cufon-ready" dir="ltr" lang="en-US"><!--<![endif]--><head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><title>Online Quiz - Review</title>

<link rel="shortcut icon" href=" favicon.ico">
<link rel="apple-touch-icon-precomposed" href="../images//apple-itouch-icon.png">

<script type="text/javascript"> 
	var fadeContent = 'all'; 
	var toolTips = 'class'; 
</script>

<link rel="stylesheet" type="text/css" href="Sample_files/base.css">
<link rel="stylesheet" type="text/css" href="Sample_files/buddypress.css">
<link rel="stylesheet" type="text/css" href="Sample_files/style-default.css">
<link rel="stylesheet" type="text/css" href="Sample_files/ddsmoothmenu.css">
<link rel="stylesheet" type="text/css" href="Sample_files/colorbox.css">
<link rel="stylesheet" type="text/css" href="Sample_files/qtip.css">
<link rel="stylesheet" type="text/css" href="Sample_files/style-skin-1.css" id="SkinCSS">
<link href="quiz.css" rel="stylesheet" type="text/css"> 
<link rel="stylesheet" id="demo-colors-css-css" href="Sample_files/styles.css" type="text/css" media="all">
<script type="text/javascript" src="Sample_files/jquery_002.js"></script>
<script type="text/javascript" src="Sample_files/widget-members.js"></script>
<script type="text/javascript" src="Sample_files/widget-groups.js"></script>
<script type="text/javascript" src="Sample_files/global.js"></script>
<script type="text/javascript" src="Sample_files/modernizr-1.js"></script>
<script type="text/javascript" src="Sample_files/swfobject.js"></script>
<script type="text/javascript" src="Sample_files/cufon-yui.js"></script>
<style type="text/css">cufon{text-indent:0!important;}@media screen,projection{cufon{display:inline!important;display:inline-block!important;position:relative!important;vertical-align:middle!important;font-size:1px!important;line-height:1px!important;}cufon cufontext{display:-moz-inline-box!important;display:inline-block!important;width:0!important;height:0!important;overflow:hidden!important;text-indent:-10000in!important;}cufon canvas{position:relative!important;}}@media print{cufon{padding:0!important;}cufon canvas{display:none!important;}}
</style>
 
<meta name="generator" content="WordPress 3.3.1">
 

	<script type="text/javascript">var ajaxurl = "#";</script>

	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>

	<script type="text/javascript"> jQuery(document).ready( function() { jQuery("a.confirm").click( function() { if ( confirm( 'Are you sure?' ) ) return true; else return false; }); });</script>

 

<script>!window.jQuery && document.write(unescape('%3Cscript src="js/libs/jquery-1.7.1.min.js"%3E%3C/script%3E'))</script>

<!--[if lte IE 8]>
<link rel="stylesheet" type="text/css" href="css/ie.css" />
<![endif]-->

<style type="text/css">
body, select, input, textarea {  font-family: Arial, Helvetica, Garuda, sans-serif; } </style> </head>

<body class="page page-id-3241 page-child parent-pageid-3134 page-template-default style-skin-1"><div style="display: none;" id="cboxOverlay"></div><div class="" id="colorbox" style="padding-bottom: 48px; padding-right: 40px; display: none;"><div style="" id="cboxWrapper"><div style=""><div style="float: left;" id="cboxTopLeft"></div><div style="float: left;" id="cboxTopCenter"></div><div style="float: left;" id="cboxTopRight"></div></div><div style="clear: left;"><div style="float: left;" id="cboxMiddleLeft"></div><div style="float: left;" id="cboxContent"><div class="" style="width: 0px; height: 0px; overflow: hidden;" id="cboxLoadedContent"></div><div class="" style="" id="cboxLoadingOverlay"></div><div class="" style="" id="cboxLoadingGraphic"></div><div class="" style="" id="cboxTitle"></div><div class="" style="" id="cboxCurrent"></div><div class="" style="" id="cboxNext"></div><div class="" style="" id="cboxPrevious"></div><div class="" style="" id="cboxSlideshow"></div><div class="" style="" id="cboxClose"></div></div><div style="float: left;" id="cboxMiddleRight"></div></div><div style="clear: left;"><div style="float: left;" id="cboxBottomLeft"></div><div style="float: left;" id="cboxBottomCenter"></div><div style="float: left;" id="cboxBottomRight"></div></div></div><div style="position: absolute; width: 9999px; visibility: hidden; display: none;"></div></div>

<div style="background-image: none; background-color: rgb(242, 240, 240); color: rgb(0, 0, 0);" id="Wrapper">
	<div style="background-image: none; background-color: rgb(206, 204, 204); color: rgb(0, 0, 0); opacity: 1;" id="Top">
		<div class="clearfix">
		
			<div id="headerWrapper" style="background: transparent;">
	<div class="inner-1">
		<div class="inner-2">
							<div id="TopPanel" class="clearfix">
					<div class="sections">
											<section id="4lct468lzl6o" class="topPanelSection primary-tab" style="display: none; ">
							<div class="ugc pageWrapper topPanelContent">
								<div id="text-11" class="widget scg_widget 4lct468lzl6o widget_text">			<div class="textwidget"><div class="col-1-3">
	<br><div class="clear"></div>
	
	<div class="textBox icon"><div class="icon48 icon-info"></div><div class="textContent"><h4 class="textBoxTitle"><cufon style="width: 48px; height: 16px;" alt="Need " class="cufon cufon-canvas"><canvas style="width: 62px; height: 17px; top: 1px; left: -1px;" height="17" width="62"></canvas><cufontext>Need </cufontext></cufon><cufon style="width: 46px; height: 16px;" alt="Help?" class="cufon cufon-canvas"><canvas style="width: 56px; height: 17px; top: 1px; left: -1px;" height="17" width="56"></canvas><cufontext>Help?</cufontext></cufon></h4><span class="theText">
		Etiam aliquam sem ac velit feugiat elementum. Nunc eu elit velit, nec 
vestibulum nibh. Curabitur ultrices, diam non ullamcorper blandit, nunc 
lacus ornare nisi, egestas rutrum magna est id nunc. Pellentesque 
imperdiet.
	</span></div></div>

	<div class="clear"></div>
</div>
<div class="col-1-3">
	<br><div class="clear"></div>
	
	<div class="textBox icon"><div class="icon48 icon-groups"></div><div class="textContent"><h4 class="textBoxTitle"><cufon style="width: 35px; height: 16px;" alt="The " class="cufon cufon-canvas"><canvas style="width: 48px; height: 17px; top: 1px; left: -1px;" height="17" width="48"></canvas><cufontext>The </cufontext></cufon><cufon style="width: 71px; height: 16px;" alt="benefits " class="cufon cufon-canvas"><canvas style="width: 85px; height: 17px; top: 1px; left: -1px;" height="17" width="85"></canvas><cufontext>benefits </cufontext></cufon><cufon style="width: 21px; height: 16px;" alt="of " class="cufon cufon-canvas"><canvas style="width: 35px; height: 17px; top: 1px; left: -1px;" height="17" width="35"></canvas><cufontext>of </cufontext></cufon><cufon style="width: 109px; height: 16px;" alt="membership:" class="cufon cufon-canvas"><canvas style="width: 122px; height: 17px; top: 1px; left: -1px;" height="17" width="122"></canvas><cufontext>membership:</cufontext></cufon></h4><span class="theText">
		Nullam eros mi, mollis in sollicitudin non, tincidunt sed enim. Sed et
 felis metus, rhoncus ornare nibh. Ut at magna leo. Suspendisse egestas 
est ac dolor imperdiet pretium. Lorem ipsum dolor sit amet, consectetur 
adipiscing elit.
	</span></div></div>

	<div class="clear"></div>
</div>
<div class="col-1-3 last">
	<div style="padding: 0 0 0 15px;">
		<h1><cufon style="width: 49px; height: 24px;" alt="Not " class="cufon cufon-canvas"><canvas style="width: 70px; height: 25px; top: 1px; left: -2px;" height="25" width="70"></canvas><cufontext>Not </cufontext></cufon><cufon style="width: 21px; height: 24px;" alt="a " class="cufon cufon-canvas"><canvas style="width: 41px; height: 25px; top: 1px; left: -2px;" height="25" width="41"></canvas><cufontext>a </cufontext></cufon><cufon style="width: 106px; height: 24px;" alt="member " class="cufon cufon-canvas"><canvas style="width: 126px; height: 25px; top: 1px; left: -2px;" height="25" width="126"></canvas><cufontext>member </cufontext></cufon><cufon style="width: 46px; height: 24px;" alt="yet?" class="cufon cufon-canvas"><canvas style="width: 63px; height: 25px; top: 1px; left: -2px;" height="25" width="63"></canvas><cufontext>yet?</cufontext></cufon></h1>
		<p>Signing up is easy and takes less and 3 minutes. Take a moment to 
create a user and get verified instantly. Register now to join the best 
community on the web.</p>
		
		<a href="#salutation-wp/register/" class="btn impactBtn">Sign up instantly!</a>
	</div>
	<div class="clear"></div>
	<br>
</div></div>
		</div>							</div>
						</section>
											<section id="4e4od16scosg" class="topPanelSection sign-in-icon" style="display: none; ">
							<div class="ugc pageWrapper topPanelContent">
								<div id="text-10" class="widget scg_widget 4e4od16scosg widget_text">			<div class="textwidget"><div class="col-1-2">
	<h1><cufon style="width: 117px; height: 24px;" alt="Members " class="cufon cufon-canvas"><canvas style="width: 138px; height: 25px; top: 1px; left: -2px;" height="25" width="138"></canvas><cufontext>Members </cufontext></cufon><cufon style="width: 55px; height: 24px;" alt="Sign " class="cufon cufon-canvas"><canvas style="width: 76px; height: 25px; top: 1px; left: -2px;" height="25" width="76"></canvas><cufontext>Sign </cufontext></cufon><cufon style="width: 23px; height: 24px;" alt="In" class="cufon cufon-canvas"><canvas style="width: 35px; height: 25px; top: 1px; left: -2px;" height="25" width="35"></canvas><cufontext>In</cufontext></cufon></h1>
	<p>Sign in to begin browsing the members areas and interracting with the community.</p>
	<form class="publicForm" method="post" action="#salutation-wp/wp-login.php">
		<div class="col-1-3">
			<div class="fieldContainer">
				<label for="log" class="formTitle">Username</label>
				<input id="log" name="log" class="textInput" style="width:90%" type="text">
			</div>
		</div>
		<div class="col-1-3">
			<div class="fieldContainer">
				<label for="pwd" class="formTitle">Password</label>
				<input id="pwd" name="pwd" class="textInput" style="width:90%" type="password">
			</div>
		</div>
		<div class="col-1-3">
			<br>
			<button type="submit" class="btn black"><span>Sign in</span></button>
		</div>
	</form>
	<div class="clear"></div>
	<br><br>
</div>
<div class="col-1-4">
	<br><div class="clear"></div>
	<h4><cufon style="width: 72px; height: 16px;" alt="Member " class="cufon cufon-canvas"><canvas style="width: 85px; height: 17px; top: 1px; left: -1px;" height="17" width="85"></canvas><cufontext>Member </cufontext></cufon><cufon style="width: 81px; height: 16px;" alt="Resources" class="cufon cufon-canvas"><canvas style="width: 91px; height: 17px; top: 1px; left: -1px;" height="17" width="91"></canvas><cufontext>Resources</cufontext></cufon></h4>

	
		<ul class="icon-list " style="margin-left: 20px;">
			<li><div class="icon16 iconSymbol check"></div><a href="#">Getting Started Guide</a></li>
			<li><div class="icon16 iconSymbol check"></div><a href="#">Author Rules and Regulations</a></li>
			<li><div class="icon16 iconSymbol check"></div><a href="#">Frequently Asked Questions</a></li>
			</ul>
	

	<br><div class="clear"></div>
</div>
<div class="col-1-4 last">
	<br><div class="clear"></div>
	<h4><cufon style="width: 96px; height: 16px;" alt="Community " class="cufon cufon-canvas"><canvas style="width: 110px; height: 17px; top: 1px; left: -1px;" height="17" width="110"></canvas><cufontext>Community </cufontext></cufon><cufon style="width: 41px; height: 16px;" alt="Tools" class="cufon cufon-canvas"><canvas style="width: 52px; height: 17px; top: 1px; left: -1px;" height="17" width="52"></canvas><cufontext>Tools</cufontext></cufon></h4>

	
		<ul class="icon-list " style="margin-left: 20px;">
			<li><div class="icon16 iconSymbol plus"></div><a href="#">Top Contributors "Wall of Fame"</a></li>
			<li><div class="icon16 iconSymbol plus"></div><a href="#">Awards and Recognitions</a></li>
			<li><div class="icon16 iconSymbol plus"></div><a href="#">Recently Featured Articles</a></li>
			</ul>
	

	<br><div class="clear"></div>
</div></div>
		</div>							</div>
						</section>
					 
				</div>
							<header>
				<div id="MainHeader" class="pageWrapper clearfix">
					<h1 id="Logo"><a href="#salutation-wp"><img src="Sample_files/logo.png" alt="Salutation" class="default" height="40" width="140"></a></h1>
			
					<div id="MainMenu">
						<div class="inner-1">
							<div class="inner-2">
								<nav>
								
									<div id="MM" class="slideMenu">
										<ul id="menu-main-menu" class="menu">
                                        
                                        <li style="z-index: 300;" id="menu-item-2990" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2990"><a class="hasSubMenu" href="login.php">Home<span class="subDown"></span></a>
 
</li>
<li style="z-index: 299;" id="menu-item-3088" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor menu-item-3088"><a class="hasSubMenu" href="#">Features<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li style="z-index: 298;" id="menu-item-2645" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2645"><a href="#">Page Layouts<span class="subRight"></span></a>
	<ul style="display: none; top: 0px; visibility: visible;" class="sub-menu">
		<li id="menu-item-2891" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2891"><a href="#salutation-wp/page-samples/page-left-sidebar/">Page: Sidebar Left</a></li>
		<li id="menu-item-2890" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2890"><a href="#salutation-wp/page-samples/page-right-sidebar/">Page: Sidebar Right</a></li>
		<li id="menu-item-2889" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2889"><a href="#salutation-wp/page-samples/page-graphic-header/">Page: Graphic Header</a></li>
		<li id="menu-item-3238" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3238"><a href="#salutation-wp/page-samples/page-slide-show-header/">Page: Slide Show Header</a></li>
		<li id="menu-item-2888" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2888"><a href="#salutation-wp/page-samples/page-with-slogan/">Page: Slogan (top banner)</a></li>
	</ul>
</li>
	<li style="z-index: 297;" id="menu-item-3334" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-3334"><a href="#">Home Pages<span class="subRight"></span></a>
	<ul style="display: none; top: 0px; visibility: visible;" class="sub-menu">
		<li id="menu-item-3337" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-3241 current_page_item menu-item-3337"><a title="Create any home page layout with the drag-and-drop Layout Generator." href="#salutation-wp/page-samples/home-page-sample-1/">Home Page: Another Sample</a></li>
	</ul>
</li>
	<li style="z-index: 296;" id="menu-item-3089" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3089"><a href="#salutation-wp/theme-features/">Admin<span class="subRight"></span></a>
	<ul style="display: none; top: 0px; visibility: visible;" class="sub-menu">
		<li id="menu-item-3090" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3090"><a href="#salutation-wp/theme-features/layout-manager/">Layout Manager</a></li>
		<li id="menu-item-3091" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3091"><a href="#salutation-wp/theme-features/blog-settings/">Blog Settings</a></li>
		<li id="menu-item-3092" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3092"><a href="#salutation-wp/theme-features/contact-form/">Contact Forms</a></li>
		<li id="menu-item-3112" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3112"><a href="#salutation-wp/theme-features/slide-show/">Slide Show</a></li>
	</ul>
</li>
</ul>
</li>
<li style="z-index: 295;" id="menu-item-1825" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1825"><a class="hasSubMenu" href="#salutation-wp/blog/">Blog<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li id="menu-item-2432" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2432"><a href="#salutation-wp/blog/">Blog: Right Sidebar</a></li>
	<li id="menu-item-3118" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3118"><a href="#salutation-wp/blog/blog-left-sidebar/">Blog: Left Sidebar</a></li>
	<li id="menu-item-3131" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3131"><a href="#salutation-wp/blog/blog-3-column/">Blog: 3 Column</a></li>
	<li id="menu-item-2433" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2433"><a href="#salutation-wp/blog/blog-layout-samples/">Blog: Post Variations</a></li>
	<li id="menu-item-3121" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-3121"><a href="#salutation-wp/blog/2011/04/13/you-think-water-moves-fast/">Single Post: Right Sidebar</a></li>
	<li id="menu-item-3120" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-3120"><a href="#salutation-wp/blog/2011/03/19/airspeed-velocity-of-a-swallow/">Single Post: Left Sidebar</a></li>
	<li id="menu-item-3126" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-3126"><a href="#salutation-wp/blog/2011/03/05/when-do-spiders-sleep/">Single Post: 3 Column</a></li>
</ul>
</li>
<li style="z-index: 294;" id="menu-item-1826" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1826"><a class="hasSubMenu" href="#salutation-wp/portfolio/">Portfolio<span class="subDown"></span></a>
 
</li>
<li style="z-index: 292;" id="menu-item-2654" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2654"><a class="hasSubMenu" href="#salutation-wp/activity/">BuddyPress<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li id="menu-item-3371" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3371"><a href="#salutation-wp/activity/">Activity</a></li>
	<li id="menu-item-3372" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3372"><a href="#salutation-wp/members/">Members</a></li>
	<li id="menu-item-3370" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3370"><a href="#salutation-wp/groups/">Groups</a></li>
	<li id="menu-item-3369" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3369"><a href="#salutation-wp/forums/">Forums</a></li>
	<li id="menu-item-3368" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3368"><a href="#salutation-wp/blogs/">Blogs</a></li>
</ul>
</li>
<li style="z-index: 291;" id="menu-item-2206" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2206"><a class="hasSubMenu" href="#">Shortcodes<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li id="menu-item-1807" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1807"><a href="#salutation-wp/shortcodes/images/">Images Styles</a></li>
	<li id="menu-item-1810" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1810"><a href="#salutation-wp/shortcodes/buttons/">Button Styles</a></li>
	<li id="menu-item-1812" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1812"><a href="#salutation-wp/shortcodes/icons-and-lists/">Icons and Lists</a></li>
	<li id="menu-item-1813" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1813"><a href="#salutation-wp/shortcodes/boxes-and-containers/">Quotes and Text Boxes</a></li>
	<li id="menu-item-1850" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1850"><a href="#salutation-wp/shortcodes/tabs-and-toggles/">Tabs and Toggles</a></li>
	<li id="menu-item-1849" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1849"><a href="#salutation-wp/shortcodes/pricing-table/">Pricing Tables</a></li>
	<li id="menu-item-1815" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1815"><a href="#salutation-wp/shortcodes/layout-columns-and-dividers/">Columns and Dividers</a></li>
	<li id="menu-item-1817" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1817"><a href="#salutation-wp/shortcodes/blog/">Blog Posts</a></li>
	<li id="menu-item-1819" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1819"><a href="#salutation-wp/shortcodes/portfolio/">Portfolio and Gallery</a></li>
	<li id="menu-item-1820" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1820"><a href="#salutation-wp/shortcodes/contact-form/">Contact Forms</a></li>
	<li id="menu-item-1823" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1823"><a href="#salutation-wp/shortcodes/slide-show/">Slide shows</a></li>
	<li id="menu-item-1824" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1824"><a href="#salutation-wp/shortcodes/miscellaneous/">Other Shortcodes</a></li>
</ul>
</li>
<li id="menu-item-1830" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1830"><a href="#salutation-wp/contact/">Contact</a></li>
<li style="z-index: 290;" id="menu-item-2466" class="-function-is-user-logged-in menu-item menu-item-type-custom menu-item-object-custom menu-item-2466"><a class="hasSubMenu cboxElement" href="index.php">Logout<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li id="menu-item-2653" class="-function-is-user-logged-in menu-item menu-item-type-custom menu-item-object-custom menu-item-2653"><a class="cboxElement" href="#LoginPopup">Account sign in</a></li>
	<li id="menu-item-3367" class="-function-is-user-logged-in menu-item menu-item-type-post_type menu-item-object-page menu-item-3367"><a href="#salutation-wp/register/">Register for an account</a></li>
</ul>
</li>
</ul>										<div style="clear:left"></div>
									</div>
																						
								</nav>
							</div>
						</div>
					</div>
			
				</div>
				
							</header>
			
	 
					
		</div>
	</div>
</div>
			
		</div>
	</div> <!--! end of #Top -->
	
	<div style="opacity: 1;" id="Middle">
		<div class="pageWrapper theContent clearfix">
			<div style="background-image: none; background-color: rgb(250, 249, 249); color: rgb(0, 0, 0);" id="MiddleInner" class="inner-1">
				<div class="inner-2 contentMargin">
			
					<div id="home-page-design-agency_c1" class="clearfix">
	<div id="home-page-design-agency_c1_col-1-1_1" class="col-1-1 clearfix"><div class="i0 ugc">	<div class="content-page">
		
		<article id="post-3241" class="post-3241 page type-page status-publish hentry">
		
			<div class="the-post-container">
			
								
				<!-- Page Text and Main Content -->
				<div class="entry-content clearfix">
					<h1 style="text-align:center; float:none;" class="cta-title">Wel come to Online Exam.</h1>

<p style="text-align:center; font-size:14px;">Created in a few minutes 
using layout shortcodes, a custom header and slide show, this page was 
customized using admin options. This is just a quick sample of how easy 
it is to customize your site for exactly the look you want in any area.</p>

<div class="clear"></div>
<hr>
<div class="clear"></div>
<br><br>

<div class="col-1-4">
<h3>My Details</h3>

<p>Last Login :  </p>

 
<p>Previous Level </p>
<p> Top Level </p>
<p> Top Level (Name) </p> 

<hr>
 
<hr>
</div>

<div class="col-1-4">
<h3><cufon style="width: 39px; height: 18px;" alt="Our " class="cufon cufon-canvas"><canvas style="width: 55px; height: 19px; top: 1px; left: -1px;" height="19" width="55"></canvas><cufontext>Our </cufontext></cufon><cufon style="width: 46px; height: 18px;" alt="Work" class="cufon cufon-canvas"><canvas style="width: 57px; height: 19px; top: 1px; left: -1px;" height="19" width="57"></canvas><cufontext>Work</cufontext></cufon></h3>


<section class="content-post-list clearfix">
	<ol class="posts-list portfolio-list">
	
	
		<li class="portfolio-item clearfix" style="width: 210px; margin-right: 0;">
			<article id="post-1045" class="post-1045 page type-page status-publish hentry type-portfolio">
				<div style="height: 105px;" class="item-container">
					
					<div class="the-post-image">
						<a href="../images/sample-image-9.jpg" class="popup cboxElement" title="Aenean hendrerit" rel="portfolio_7b7si4qiko84"><figure><img src="Sample_files/sample-image-9-210x105.jpg" height="105" width="210"></figure></a>					</div>
					
							
				</div>

			</article>
		</li>
		
		
		 
		
		
		
			
	</ol>
</section>



</div>

<div class="col-1-2 last">
<h3><cufon style="width: 39px; height: 18px;" alt="Our " class="cufon cufon-canvas"><canvas style="width: 55px; height: 19px; top: 1px; left: -1px;" height="19" width="55"></canvas><cufontext>Our </cufontext></cufon><cufon style="width: 60px; height: 18px;" alt="Clients" class="cufon cufon-canvas"><canvas style="width: 71px; height: 19px; top: 1px; left: -1px;" height="19" width="71"></canvas><cufontext>Clients</cufontext></cufon></h3>

   
   
   

<div class="clear"></div>

 



<section class="content-post-list">
	<ol class="posts-list hfeed">
	
	
		<li class="post-item clearfix">
			<article id="post-534" class="post-534 post type-post status-publish format-standard hentry category-news noImage"></article>
		</li>
		
		
		<li class="post-item clearfix">
			<article id="post-524" class="post-524 post type-post status-publish format-standard hentry category-community category-news noImage">
				<div class="item-container">
				
										
					<div class="the-post-content"><!-- Content -->
						<div class="entry-content" align="center">
							 						
							 <?php

echo "<h1 class='head1'> Review Test Question</h1>";

if(!isset($_SESSION['qn']))
{
		$_SESSION['qn']=0;
}
else if(isset($_POST['submit']))
{$submit=$_POST['submit'];
	if($submit=='Next Question' )
	{
		$_SESSION['qn']=$_SESSION['qn']+1;
	}
}

$qn=$_SESSION['qn'];
$q=$_SESSION['q_arr'][$qn];
//echo $q;
$query="SELECT * FROM mst_question WHERE que_id ='$q' ";
$rs=mysql_query($query,$cn) or die(mysql_error());
$row= mysql_fetch_row($rs);
echo "<form name=myfm method=post action=review.php>";
echo "<table width=100%> <tr> <td width=30>&nbsp;<td> <table border=0>";

$n=$_SESSION['qn']+1;
echo "<tr><td><span class=style2>Que ".  $n .": $row[3]</style>";
echo "<tr><td class=".($row['8']==1?'tans':'style8').">$row[4]";
echo "<tr><td class=".($row['8']==2?'tans':'style8').">$row[5]";
echo "<tr><td class=".($row['8']==3?'tans':'style8').">$row[6]";
echo "<tr><td class=".($row['8']==4?'tans':'style8').">$row[7]";
$t_id=$_SESSION['tid'];
$set_id=$_SESSION['set_id'];
$qry="SELECT * FROM mst_question WHERE test_id = $t_id AND set_id = $set_id";
$res=mysql_query($qry,$cn) or die(mysql_error());


if($_SESSION['qn']<mysql_num_rows($res)-1)
echo "<tr><td><input type=submit name=submit value='Next Question'></form>";
else
echo "<tr><td><input type=submit name=submit value='Finish'></form>";

echo "</table></table>";
?>

						
						</div><!-- END .entry-content -->
			
						<!-- Post Footer -->
						<footer class="post-footer-info">
													</footer><!-- END .post-footer-info -->
					</div>
		
				</div>
			</article>
		</li>
		
			
	</ol>
</section>




</div>

<style type="text/css"> .slideShowPager { display: none; } #SS-1-1 { margin-left: 24px; } .slideShow { background-color: #414B52; } </style>				</div>
	
				<!-- Post Extras -->
				<footer class="postFooter">
										<div class="nextPageLinks">  </div>
									</footer>
				
					
			</div>
		</article>
		
	</div>
	</div></div> <!-- END id=home-page-design-agency_c1_col-1-1_1 class=col-1-1 -->
</div> <!-- END id=home-page-design-agency_container_1 -->

			
				</div>
			</div>
		</div> <!--! end of .pageWrapper -->
	</div> <!--! end of #Middle -->
	
	<div style="opacity: 1;" id="Bottom">		

		<footer style="background: transparent;">
	<div style="background-image: none; background-color: rgb(65, 75, 82); color: rgb(255, 255, 255);" id="BottomInner" class="pageWrapper theContent clearfix">
		<div class="inner-1">
			<div class="inner-2">
									<div class="ugc clearfix">
						<div class="staticBlockWrapper ugc" style="background: transparent;"><div class="staticContent scid-1710">
<div class="col-1-2">
<h3 class="sectionTitle"><cufon style="width: 52px; height: 13px;" alt="About " class="cufon cufon-canvas"><canvas style="width: 63px; height: 14px; top: 0px; left: -1px;" height="14" width="63"></canvas><cufontext>About </cufontext></cufon><cufon style="width: 30px; height: 13px;" alt="The " class="cufon cufon-canvas"><canvas style="width: 41px; height: 14px; top: 0px; left: -1px;" height="14" width="41"></canvas><cufontext>The </cufontext></cufon><cufon style="width: 47px; height: 13px;" alt="Theme" class="cufon cufon-canvas"><canvas style="width: 54px; height: 14px; top: 0px; left: -1px;" height="14" width="54"></canvas><cufontext>Theme</cufontext></cufon></h3>
<p><a href="#salutation-wp" title="Home">Salutation</a> is a premium WordPress theme created by <a href="#" title="Website" target="_blank">Parallelus</a>
 and available for purchase on ThemeForest. Developed using web 
standards such as HTML5, CSS3 and WordPress best practices. The theme is
 <a href="#/" title="Visit BuddyPress Website" target="_blank">BuddyPress</a> ready with the necessary tools to create your own social network.</p>
</div>

<div class="col-1-4">
<h3 class="sectionTitle"><cufon style="width: 44px; height: 13px;" alt="What " class="cufon cufon-canvas"><canvas style="width: 55px; height: 14px; top: 0px; left: -1px;" height="14" width="55"></canvas><cufontext>What </cufontext></cufon><cufon style="width: 16px; height: 13px;" alt="is " class="cufon cufon-canvas"><canvas style="width: 27px; height: 14px; top: 0px; left: -1px;" height="14" width="27"></canvas><cufontext>is </cufontext></cufon><cufon style="width: 95px; height: 13px;" alt="BuddyPress?" class="cufon cufon-canvas"><canvas style="width: 104px; height: 14px; top: 0px; left: -1px;" height="14" width="104"></canvas><cufontext>BuddyPress?</cufontext></cufon></h3>
<p><a href="#" title="Visit Website" target="_blank">BuddyPress</a> is a <a href="http://wordpress.org/" title="Visit WordPress Website" target="_blank">WordPress</a> plugin to make your website a social network with community features like groups, forums, messaging, blogs and more.</p>
</div>

<div class="col-1-4 last">
<div>Follow us: <a oldtitle="Twitter" href="http://twitter.com/" target="_blank" class="tip">Twitter</a> | <a oldtitle="Buzz" href="http://www.google.com" target="_blank" class="tip">Buzz</a> | <a oldtitle="Facebook" href="https://www.facebook.com/" target="_blank" class="tip">Facebook</a></div>
</div>

<div class="clear"></div>

<div style="margin: 30px 0 0;">
<a href="#" title="Parallelus Inc." target="_blank"><img src="Sample_files/logo-small-white.png" alt="Salutation - A Premium BuddyPress Theme" height="27" width="107"></a>
<p>Copyright © 2011 <a href="#" title="Parallelus Inc." target="_blank">Parall</a>. All rights reserved.</p>
</div><div class="clear"></div></div></div>					</div>
							</div>
		</div>
	</div>
</footer>		
	</div> <!--! end of #Bottom -->
</div> <!--! end of #Wrapper -->
</body></html>
<?php
}
else
{
	?><script> location='index.php'; </script>
<?php }?>  