<?php
session_start();?>
<body background="geometric-retro-pattern1.png">
<div align="center" style="margin-top:10%">
<font size="+6" face="Arial Black, Gadget, sans-serif" color="#330066">New Achivement</font>
<br>
<?php unset($_SESSION['nxt']);?>
<?php 
$level=$_SESSION['level'];
$level=$level+1;
$_SESSION['level']=$level;
?>
<font size="+3" face="Arial, Gadget, sans-serif" color="#CC6699">Level <?php echo  $_SESSION['level']; ?> Unlocked</font><br />
<div style="margin-top:15px">
<a href="main_quiz.php" style="color:#FFCC99">Next Question</a>
</div>
</div>
</body>