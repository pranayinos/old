<?php
include("database.php");
$email = $_GET["q"];
$sql="SELECT `user_id` FROM `mst_user` WHERE `email`='$email'";
$result = mysql_query($sql);
$match = mysql_num_rows($result);
			//echo $match;
			if($match > 0)
			{
				echo "<span style='color:#FF0000'>this email is already registered</span>";
			}
?>
