<?php
require "database.php";
if((isset($_POST['sub']))&&(isset($_POST['name']))&&(isset($_POST['message']))&&(isset($_POST['email'])))
{
	$name=$_POST['name'];
	$email=$_POST['email'];
	$phone=$_POST['phoneno'];
	$message=$_POST['message'];
	$ok=0;
	/*echo $name;
	echo $email;
	echo $phone;
	echo $phone;
	echo $message;*/
	$qry="INSERT INTO `posts` (`name`, `email`, `phone`, `message`) VALUES ('$name', '$email', '$phone', '$message')";
	$result1=mysql_query($qry);
	if($result1)
	{
		$ok=1;
		echo "<br><br><br><h2 align='center'> Thanks for your feedback</h2><br><p align='center'><a href='index.php'>Home</a></p>";
	
	}
			
//echo "<br>".$_FILES["file"]["tmp_name"]."<br>".$qry;
}
else
{
?>
<script>
location="testimonials.php?<?php echo $ok ?>";
/*function (id)
{
	location='../testimonials.php?'+id;
}*/
</script>
<?php }
?>