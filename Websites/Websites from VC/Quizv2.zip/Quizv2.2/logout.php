<?php
session_start();
				unset($_SESSION['login']);
				unset($_SESSION['user_id']);
				unset($_SESSION['sid']);
				unset($_SESSION['tid']);
				unset($_SESSION['set']);
				unset($_SESSION['qn']);
				unset($_SESSION['level']);
				unset($_SESSION['trueans']);
				unset($_SESSION['q_arr']);
				 include("database.php");	
				 
				
?><script> location='index.php'; </script>