<?php
include("database.php");
$sub_id = $_GET["q"];
$sql="SELECT * FROM `mst_test` WHERE `sub_id`='$sub_id'";
$result = mysql_query($sql);
?>
<select name="test" id="test" style="width:140px">
<option value="0">--Select Test--</option>
<?php
while($row=mysql_fetch_array($result))
{
$id=$row['test_id'];
$test=$row['test_name'];
echo '<option value="'.$id.'">'.$test.'</option>';
}
?>
</select>