<?php 
if((isset($_POST['newpassword']))&&(isset($_POST['email'])))
{
	include("database.php");
	$newpassword=md5($_POST['newpassword']);
	$email=$_POST['email'];
	$qry_chk="UPDATE `mst_user`SET `pass`='$newpassword' WHERE `email`='$email'";
	$rs=mysql_query($qry_chk,$cn);
	


?>
<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html class=" js flexbox canvas canvastext no-webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms no-csstransforms3d csstransitions fontface video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths cufon-active cufon-ready" dir="ltr" lang="en-US"><!--<![endif]--><head><style type="text/css"></style>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><title>Account Created</title>

<link rel="shortcut icon" href="favicon.ico">
<link rel="apple-touch-icon-precomposed" href="apple-itouch-icon.png">

<script type="text/javascript"> 
	var fadeContent = 'all'; 
	var toolTips = 'class'; 
</script>

<link rel="stylesheet" type="text/css" href="css/base.css">
<link rel="stylesheet" type="text/css" href="css/buddypress.css">
<link rel="stylesheet" type="text/css" href="css/style-default.css">
<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css">
<link rel="stylesheet" type="text/css" href="css/colorbox.css">
<link rel="stylesheet" type="text/css" href="css/qtip.css">
<link rel="stylesheet" type="text/css" href="css/style-skin-1.css" id="SkinCSS">
<link rel="alternate" type="application/rss+xml" title="Salutation » Feed" href="themes/salutation-wp/feed/">
<link rel="alternate" type="application/rss+xml" title="Salutation » Comments Feed" href="themes/salutation-wp/comments/feed/">
<link rel="stylesheet" id="demo-colors-css-css" href="css/styles.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/widget-members.js"></script>
<script type="text/javascript" src="js/widget-groups.js"></script>
<script type="text/javascript" src="js/global.js"></script>
<script type="text/javascript" src="js/modernizr-1.js"></script>
<script type="text/javascript" src="js/swfobject.js"></script>
<script type="text/javascript" src="js/cufon-yui.js"></script><style type="text/css">cufon{text-indent:0!important;}@media screen,projection{cufon{display:inline!important;display:inline-block!important;position:relative!important;vertical-align:middle!important;font-size:1px!important;line-height:1px!important;}cufon cufontext{display:-moz-inline-box!important;display:inline-block!important;width:0!important;height:0!important;overflow:hidden!important;text-indent:-10000in!important;}cufon canvas{position:relative!important;}}@media print{cufon{padding:0!important;}cufon canvas{display:none!important;}}</style>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="themes/salutation-wp/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="themes/salutation-wp/wp-includes/wlwmanifest.xml"> 
<link rel="prev" title="Home Page: Sample 1" href="themes/salutation-wp/page-samples/home-page-sample-1/">
<meta name="generator" content="WordPress 3.3.1">
<link rel="canonical" href="themes/salutation-wp/register/">

	<script type="text/javascript">var ajaxurl = "themes/salutation-wp/wp-load.php";</script>
<script src="Js/jquery-1.7.1.min.js"></script>
<script  src="Js/jquery.validate.min.js"></script>
	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>

	<script type="text/javascript"> jQuery(document).ready( function() { jQuery("a.confirm").click( function() { if ( confirm( 'Are you sure?' ) ) return true; else return false; }); });</script>



<script>!window.jQuery && document.write(unescape('%3Cscript src="js/jquery-1.7.1.min.js"%3E%3C/script%3E'))</script>

<!--[if lte IE 8]>
<link rel="stylesheet" type="text/css" href="css/ie.css" />
<![endif]-->

<style type="text/css">
body, select, input, textarea {  font-family: Arial, Helvetica, Garuda, sans-serif; } </style> 
</head>

<body class="registration register  style-skin-1"><div style="display: none;" id="cboxOverlay"></div><div class="" id="colorbox" style="padding-bottom: 48px; padding-right: 40px; display: none;"><div style="" id="cboxWrapper"><div style=""><div style="float: left;" id="cboxTopLeft"></div><div style="float: left;" id="cboxTopCenter"></div><div style="float: left;" id="cboxTopRight"></div></div><div style="clear: left;"><div style="float: left;" id="cboxMiddleLeft"></div><div style="float: left;" id="cboxContent"><div class="" style="width: 0px; height: 0px; overflow: hidden;" id="cboxLoadedContent"></div><div class="" style="" id="cboxLoadingOverlay"></div><div class="" style="" id="cboxLoadingGraphic"></div><div class="" style="" id="cboxTitle"></div><div class="" style="" id="cboxCurrent"></div><div class="" style="" id="cboxNext"></div><div class="" style="" id="cboxPrevious"></div><div class="" style="" id="cboxSlideshow"></div><div class="" style="" id="cboxClose"></div></div><div style="float: left;" id="cboxMiddleRight"></div></div><div style="clear: left;"><div style="float: left;" id="cboxBottomLeft"></div><div style="float: left;" id="cboxBottomCenter"></div><div style="float: left;" id="cboxBottomRight"></div></div></div><div style="position: absolute; width: 9999px; visibility: hidden; display: none;"></div></div>

<div style="background-image: none; background-color: rgb(242, 240, 240); color: rgb(0, 0, 0);" id="Wrapper">
	<div style="background-image: none; background-color: rgb(206, 204, 204); color: rgb(0, 0, 0); opacity: 1;" id="Top">
		<div class="clearfix">
		
			<div id="headerWrapper" style="background: transparent;">
	<div class="inner-1">
		<div class="inner-2">
							<div id="TopPanel" class="clearfix">
					<div class="sections">
											<section id="4lct468lzl6o" class="topPanelSection primary-tab" style="display: none; ">
							<div class="ugc pageWrapper topPanelContent">
								<div id="text-11" class="widget scg_widget 4lct468lzl6o widget_text">			<div class="textwidget"><div class="col-1-3">
	<br><div class="clear"></div>
	
	<div class="textBox icon"><div class="icon48 icon-info"></div><div class="textContent"><h4 class="textBoxTitle"><cufon style="width: 48px; height: 16px;" alt="Need " class="cufon cufon-canvas"><canvas style="width: 62px; height: 17px; top: 1px; left: -1px;" height="17" width="62"></canvas><cufontext>Need </cufontext></cufon><cufon style="width: 46px; height: 16px;" alt="Help?" class="cufon cufon-canvas"><canvas style="width: 56px; height: 17px; top: 1px; left: -1px;" height="17" width="56"></canvas><cufontext>Help?</cufontext></cufon></h4><span class="theText">
		Etiam aliquam sem ac velit feugiat elementum. Nunc eu elit velit, nec 
vestibulum nibh. Curabitur ultrices, diam non ullamcorper blandit, nunc 
lacus ornare nisi, egestas rutrum magna est id nunc. Pellentesque 
imperdiet.
	</span></div></div>

	<div class="clear"></div>
</div>
<div class="col-1-3">
	<br><div class="clear"></div>
	
	<div class="textBox icon"><div class="icon48 icon-groups"></div><div class="textContent"><h4 class="textBoxTitle"><cufon style="width: 35px; height: 16px;" alt="The " class="cufon cufon-canvas"><canvas style="width: 48px; height: 17px; top: 1px; left: -1px;" height="17" width="48"></canvas><cufontext>The </cufontext></cufon><cufon style="width: 71px; height: 16px;" alt="benefits " class="cufon cufon-canvas"><canvas style="width: 85px; height: 17px; top: 1px; left: -1px;" height="17" width="85"></canvas><cufontext>benefits </cufontext></cufon><cufon style="width: 21px; height: 16px;" alt="of " class="cufon cufon-canvas"><canvas style="width: 35px; height: 17px; top: 1px; left: -1px;" height="17" width="35"></canvas><cufontext>of </cufontext></cufon><cufon style="width: 109px; height: 16px;" alt="membership:" class="cufon cufon-canvas"><canvas style="width: 122px; height: 17px; top: 1px; left: -1px;" height="17" width="122"></canvas><cufontext>membership:</cufontext></cufon></h4><span class="theText">
		Nullam eros mi, mollis in sollicitudin non, tincidunt sed enim. Sed et
 felis metus, rhoncus ornare nibh. Ut at magna leo. Suspendisse egestas 
est ac dolor imperdiet pretium. Lorem ipsum dolor sit amet, consectetur 
adipiscing elit.
	</span></div></div>

	<div class="clear"></div>
</div>
<div class="col-1-3 last">
	<div style="padding: 0 0 0 15px;">
		<h1><cufon style="width: 49px; height: 24px;" alt="Not " class="cufon cufon-canvas"><canvas style="width: 70px; height: 25px; top: 1px; left: -2px;" height="25" width="70"></canvas><cufontext>Not </cufontext></cufon><cufon style="width: 21px; height: 24px;" alt="a " class="cufon cufon-canvas"><canvas style="width: 41px; height: 25px; top: 1px; left: -2px;" height="25" width="41"></canvas><cufontext>a </cufontext></cufon><cufon style="width: 106px; height: 24px;" alt="member " class="cufon cufon-canvas"><canvas style="width: 126px; height: 25px; top: 1px; left: -2px;" height="25" width="126"></canvas><cufontext>member </cufontext></cufon><cufon style="width: 46px; height: 24px;" alt="yet?" class="cufon cufon-canvas"><canvas style="width: 63px; height: 25px; top: 1px; left: -2px;" height="25" width="63"></canvas><cufontext>yet?</cufontext></cufon></h1>
		<p>Signing up is easy and takes less and 3 minutes. Take a moment to 
create a user and get verified instantly. Register now to join the best 
community on the web.</p>
		
		<a href="themes/salutation-wp/register/" class="btn impactBtn">Sign up instantly!</a>
	</div>
	<div class="clear"></div>
	<br>
</div></div>
		</div>							</div>
						</section>
											<section id="4e4od16scosg" class="topPanelSection sign-in-icon" style="display: none; ">
							<div class="ugc pageWrapper topPanelContent">
								<div id="text-10" class="widget scg_widget 4e4od16scosg widget_text">			<div class="textwidget"><div class="col-1-2">
	<h1><cufon style="width: 117px; height: 24px;" alt="Members " class="cufon cufon-canvas"><canvas style="width: 138px; height: 25px; top: 1px; left: -2px;" height="25" width="138"></canvas><cufontext>Members </cufontext></cufon><cufon style="width: 55px; height: 24px;" alt="Sign " class="cufon cufon-canvas"><canvas style="width: 76px; height: 25px; top: 1px; left: -2px;" height="25" width="76"></canvas><cufontext>Sign </cufontext></cufon><cufon style="width: 23px; height: 24px;" alt="In" class="cufon cufon-canvas"><canvas style="width: 35px; height: 25px; top: 1px; left: -2px;" height="25" width="35"></canvas><cufontext>In</cufontext></cufon></h1>
	<p>Sign in to begin browsing the members areas and interracting with the community.</p>
	<form class="publicForm" method="post" action="login.php">
		<div class="col-1-3">
			<div class="fieldContainer">
				<label for="log" class="formTitle">Username</label>
				<input id="log" name="log" class="textInput" style="width:90%" type="text">
			</div>
		</div>
		<div class="col-1-3">
			<div class="fieldContainer">
				<label for="pwd" class="formTitle">Password</label>
				<input id="pwd" name="pwd" class="textInput" style="width:90%" type="password">
			</div>
		</div>
		<div class="col-1-3">
			<br>
			<button type="submit" class="btn black"><span>Sign in</span></button>
		</div>
	</form>
	<div class="clear"></div>
	<br><br>
</div>
<div class="col-1-4">
	<br><div class="clear"></div>
	<h4><cufon style="width: 72px; height: 16px;" alt="Member " class="cufon cufon-canvas"><canvas style="width: 85px; height: 17px; top: 1px; left: -1px;" height="17" width="85"></canvas><cufontext>Member </cufontext></cufon><cufon style="width: 81px; height: 16px;" alt="Resources" class="cufon cufon-canvas"><canvas style="width: 91px; height: 17px; top: 1px; left: -1px;" height="17" width="91"></canvas><cufontext>Resources</cufontext></cufon></h4>

	
		<ul class="icon-list " style="margin-left: 20px;">
			<li><div class="icon16 iconSymbol check"></div><a href="#">Getting Started Guide</a></li>
			<li><div class="icon16 iconSymbol check"></div><a href="#">Author Rules and Regulations</a></li>
			<li><div class="icon16 iconSymbol check"></div><a href="#">Frequently Asked Questions</a></li>
			</ul>
	

	<br><div class="clear"></div>
</div>
<div class="col-1-4 last">
	<br><div class="clear"></div>
	<h4><cufon style="width: 96px; height: 16px;" alt="Community " class="cufon cufon-canvas"><canvas style="width: 110px; height: 17px; top: 1px; left: -1px;" height="17" width="110"></canvas><cufontext>Community </cufontext></cufon><cufon style="width: 41px; height: 16px;" alt="Tools" class="cufon cufon-canvas"><canvas style="width: 52px; height: 17px; top: 1px; left: -1px;" height="17" width="52"></canvas><cufontext>Tools</cufontext></cufon></h4>

	
		<ul class="icon-list " style="margin-left: 20px;">
			<li><div class="icon16 iconSymbol plus"></div><a href="#">Top Contributors "Wall of Fame"</a></li>
			<li><div class="icon16 iconSymbol plus"></div><a href="#">Awards and Recognitions</a></li>
			<li><div class="icon16 iconSymbol plus"></div><a href="#">Recently Featured Articles</a></li>
			</ul>
	

	<br><div class="clear"></div>
</div></div>
		</div>							</div>
						</section>
										</div>
					<ul class="section-tabs pageWrapper">
					<li><a href="#4lct468lzl6o" id="Section-Tab-4lct468lzl6o" class="sectionTab primary-tab" style="">REGISTER</a></li><li><a href="#4e4od16scosg" id="Section-Tab-4e4od16scosg" class="sectionTab sign-in-icon" style="">SIGN IN</a></li>					</ul>
				</div>
							<header>
				<div id="MainHeader" class="pageWrapper clearfix">
					<h1 id="Logo"><a href="themes/salutation-wp"><img src="images/logo.png" alt="Salutation" class="default" height="40" width="140"></a></h1>
			
					<div id="MainMenu">
						<div class="inner-1">
							<div class="inner-2">
								<nav>
								
									<div id="MM" class="slideMenu">
										<ul id="menu-main-menu" class="menu"><li style="z-index: 300;" id="menu-item-2990" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2990"><a class="hasSubMenu" href="#">Styles<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li id="menu-item-2991" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2991"><a href="/themes/salutation-wp/register/?style=1">Light</a></li>
	<li id="menu-item-2992" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2992"><a href="/themes/salutation-wp/register/?style=2">Dark</a></li>
	<li id="menu-item-3373" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3373"><a href="/themes/salutation-wp/register/?style=3">Purple</a></li>
</ul>
</li>
<li style="z-index: 299;" id="menu-item-3088" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3088"><a class="hasSubMenu" href="#">Features<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li style="z-index: 298;" id="menu-item-2645" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2645"><a href="#">Page Layouts<span class="subRight"></span></a>
	<ul style="display: none; top: 0px; visibility: visible;" class="sub-menu">
		<li id="menu-item-2891" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2891"><a href="themes/salutation-wp/page-samples/page-left-sidebar/">Page: Sidebar Left</a></li>
		<li id="menu-item-2890" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2890"><a href="themes/salutation-wp/page-samples/page-right-sidebar/">Page: Sidebar Right</a></li>
		<li id="menu-item-2889" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2889"><a href="themes/salutation-wp/page-samples/page-graphic-header/">Page: Graphic Header</a></li>
		<li id="menu-item-3238" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3238"><a href="themes/salutation-wp/page-samples/page-slide-show-header/">Page: Slide Show Header</a></li>
		<li id="menu-item-2888" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2888"><a href="themes/salutation-wp/page-samples/page-with-slogan/">Page: Slogan (top banner)</a></li>
	</ul>
</li>
	<li style="z-index: 297;" id="menu-item-3334" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3334"><a href="#">Home Pages<span class="subRight"></span></a>
	<ul style="display: none; top: 0px; visibility: visible;" class="sub-menu">
		<li id="menu-item-3337" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3337"><a title="Create any home page layout with the drag-and-drop Layout Generator." href="themes/salutation-wp/page-samples/home-page-sample-1/">Home Page: Another Sample</a></li>
	</ul>
</li>
	<li style="z-index: 296;" id="menu-item-3089" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3089"><a href="themes/salutation-wp/theme-features/">Admin<span class="subRight"></span></a>
	<ul style="display: none; top: 0px; visibility: visible;" class="sub-menu">
		<li id="menu-item-3090" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3090"><a href="themes/salutation-wp/theme-features/layout-manager/">Layout Manager</a></li>
		<li id="menu-item-3091" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3091"><a href="themes/salutation-wp/theme-features/blog-settings/">Blog Settings</a></li>
		<li id="menu-item-3092" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3092"><a href="themes/salutation-wp/theme-features/contact-form/">Contact Forms</a></li>
		<li id="menu-item-3112" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3112"><a href="themes/salutation-wp/theme-features/slide-show/">Slide Show</a></li>
	</ul>
</li>
</ul>
</li>
<li style="z-index: 295;" id="menu-item-1825" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1825"><a class="hasSubMenu" href="themes/salutation-wp/blog/">Blog<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li id="menu-item-2432" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2432"><a href="themes/salutation-wp/blog/">Blog: Right Sidebar</a></li>
	<li id="menu-item-3118" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3118"><a href="themes/salutation-wp/blog/blog-left-sidebar/">Blog: Left Sidebar</a></li>
	<li id="menu-item-3131" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3131"><a href="themes/salutation-wp/blog/blog-3-column/">Blog: 3 Column</a></li>
	<li id="menu-item-2433" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2433"><a href="themes/salutation-wp/blog/blog-layout-samples/">Blog: Post Variations</a></li>
	<li id="menu-item-3121" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-3121"><a href="themes/salutation-wp/blog/2011/04/13/you-think-water-moves-fast/">Single Post: Right Sidebar</a></li>
	<li id="menu-item-3120" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-3120"><a href="themes/salutation-wp/blog/2011/03/19/airspeed-velocity-of-a-swallow/">Single Post: Left Sidebar</a></li>
	<li id="menu-item-3126" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-3126"><a href="themes/salutation-wp/blog/2011/03/05/when-do-spiders-sleep/">Single Post: 3 Column</a></li>
</ul>
</li>
<li style="z-index: 294;" id="menu-item-1826" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1826"><a class="hasSubMenu" href="themes/salutation-wp/portfolio/">Portfolio<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li style="z-index: 293;" id="menu-item-1828" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1828"><a href="themes/salutation-wp/portfolio/">Portfolio: Images<span class="subRight"></span></a>
	<ul style="display: none; top: 0px; visibility: visible;" class="sub-menu">
		<li id="menu-item-2650" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2650"><a href="themes/salutation-wp/portfolio/sample-portfolio-2-column/">2 Column</a></li>
		<li id="menu-item-2651" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2651"><a href="themes/salutation-wp/portfolio/sample-portfolio-3-column/">3 Column</a></li>
		<li id="menu-item-3152" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3152"><a href="themes/salutation-wp/portfolio/sample-portfolio-4-column/">4 Column</a></li>
		<li id="menu-item-3160" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3160"><a href="themes/salutation-wp/portfolio/sample-portfolio-5-column/">5 Column</a></li>
		<li id="menu-item-3166" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3166"><a href="themes/salutation-wp/portfolio/sample-portfolio-5-column-sidebar-left/">5 Column: Sidebar Left</a></li>
		<li id="menu-item-2652" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2652"><a href="themes/salutation-wp/portfolio/sample-portfolio-5-column-with-sidebar/">5 Column: Sidebar Right</a></li>
	</ul>
</li>
	<li id="menu-item-1829" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1829"><a href="themes/salutation-wp/portfolio/video-portfolio/">Portfolio: Videos</a></li>
	<li id="menu-item-1827" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1827"><a href="themes/salutation-wp/portfolio/gallery/">Gallery</a></li>
</ul>
</li>
<li style="z-index: 292;" id="menu-item-2654" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2654"><a class="hasSubMenu" href="themes/salutation-wp/activity/">BuddyPress<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li id="menu-item-3371" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3371"><a href="themes/salutation-wp/activity/">Activity</a></li>
	<li id="menu-item-3372" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3372"><a href="themes/salutation-wp/members/">Members</a></li>
	<li id="menu-item-3370" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3370"><a href="themes/salutation-wp/groups/">Groups</a></li>
	<li id="menu-item-3369" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3369"><a href="themes/salutation-wp/forums/">Forums</a></li>
	<li id="menu-item-3368" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3368"><a href="themes/salutation-wp/blogs/">Blogs</a></li>
</ul>
</li>
<li style="z-index: 291;" id="menu-item-2206" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2206"><a class="hasSubMenu" href="#">Shortcodes<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li id="menu-item-1807" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1807"><a href="themes/salutation-wp/shortcodes/images/">Images Styles</a></li>
	<li id="menu-item-1810" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1810"><a href="themes/salutation-wp/shortcodes/buttons/">Button Styles</a></li>
	<li id="menu-item-1812" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1812"><a href="themes/salutation-wp/shortcodes/icons-and-lists/">Icons and Lists</a></li>
	<li id="menu-item-1813" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1813"><a href="themes/salutation-wp/shortcodes/boxes-and-containers/">Quotes and Text Boxes</a></li>
	<li id="menu-item-1850" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1850"><a href="themes/salutation-wp/shortcodes/tabs-and-toggles/">Tabs and Toggles</a></li>
	<li id="menu-item-1849" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1849"><a href="themes/salutation-wp/shortcodes/pricing-table/">Pricing Tables</a></li>
	<li id="menu-item-1815" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1815"><a href="themes/salutation-wp/shortcodes/layout-columns-and-dividers/">Columns and Dividers</a></li>
	<li id="menu-item-1817" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1817"><a href="themes/salutation-wp/shortcodes/blog/">Blog Posts</a></li>
	<li id="menu-item-1819" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1819"><a href="themes/salutation-wp/shortcodes/portfolio/">Portfolio and Gallery</a></li>
	<li id="menu-item-1820" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1820"><a href="themes/salutation-wp/shortcodes/contact-form/">Contact Forms</a></li>
	<li id="menu-item-1823" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1823"><a href="themes/salutation-wp/shortcodes/slide-show/">Slide shows</a></li>
	<li id="menu-item-1824" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1824"><a href="themes/salutation-wp/shortcodes/miscellaneous/">Other Shortcodes</a></li>
</ul>
</li>
<li id="menu-item-1830" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1830"><a href="themes/salutation-wp/contact/">Contact</a></li>
<li style="z-index: 290;" id="menu-item-2466" class="-function-is-user-logged-in menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-2466"><a class="hasSubMenu cboxElement" href="#LoginPopup">Sign in<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li id="menu-item-2653" class="-function-is-user-logged-in menu-item menu-item-type-custom menu-item-object-custom menu-item-2653"><a class="cboxElement" href="#LoginPopup">Account sign in</a></li>
	<li id="menu-item-3367" class="-function-is-user-logged-in menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-3365 current_page_item menu-item-3367"><a href="themes/salutation-wp/register/">Register for an account</a></li>
</ul>
</li>
</ul>										<div style="clear:left"></div>
									</div>
																						
								</nav>
							</div>
						</div>
					</div>
			
				</div>
				
							</header>
			
							<div id="PageTop" class="showShadow">
					<div style="background-image: none; background-color: rgb(242, 240, 240); color: rgb(0, 0, 0);" id="HeaderInner" class="inner-1 pageWrapper">
						<div class="staticBlockWrapper ugc" style="background: transparent;"><div class="staticContent scid-1786"><div style="margin: -11px 0 -7px"><div class="breadcrumbs"><a href="themes/salutation-wp">Home</a> &nbsp;/&nbsp; Register</div></div><div class="clear"></div></div></div>					</div>
				</div>
					
		</div>
	</div>
</div>
			
		</div>
	</div> <!--! end of #Top -->
	
	<div style="opacity: 1;" id="Middle">
		<div class="pageWrapper theContent clearfix">
			<div style="background-image: none; background-color: rgb(250, 249, 249); color: rgb(0, 0, 0);" id="MiddleInner" class="inner-1">
				<div class="inner-2 contentMargin">
			
				  <div id="page-right-sidebar_c1" class="clearfix"><!-- END id=page-right-sidebar_c1_col-3-4_1 class=col-3-4 --><!-- END id=page-right-sidebar_c1_col-1-4_2 class=col-1-4 -->
                  <?php   
									if($rs)
									{
										echo"<h2 align='center'>Done <a href='index.php'>login</a></h2>";
										
									}
									else
									{
										echo"<h2 align='center'>Done <a href='index.php'>login</a></h2>";
									}
}
					?>  
</div> 
					<!-- END id=page-right-sidebar_container_1 -->

			
				</div>
			</div>
		</div> <!--! end of .pageWrapper -->
	</div> <!--! end of #Middle -->
	
	<div style="opacity: 1;" id="Bottom">		

		<footer style="background: transparent;">
	<div style="background-image: none; background-color: rgb(65, 75, 82); color: rgb(255, 255, 255);" id="BottomInner" class="pageWrapper theContent clearfix">
		<div class="inner-1">
			<div class="inner-2">
									<div class="ugc clearfix">
						<div class="staticBlockWrapper ugc" style="background: transparent;"><div class="staticContent scid-1710">
<div class="col-1-2">
<h3 class="sectionTitle"><cufon style="width: 52px; height: 13px;" alt="About " class="cufon cufon-canvas"><canvas style="width: 63px; height: 14px; top: 0px; left: -1px;" height="14" width="63"></canvas><cufontext>About </cufontext></cufon><cufon style="width: 30px; height: 13px;" alt="The " class="cufon cufon-canvas"><canvas style="width: 41px; height: 14px; top: 0px; left: -1px;" height="14" width="41"></canvas><cufontext>The </cufontext></cufon><cufon style="width: 47px; height: 13px;" alt="Theme" class="cufon cufon-canvas"><canvas style="width: 54px; height: 14px; top: 0px; left: -1px;" height="14" width="54"></canvas><cufontext>Theme</cufontext></cufon></h3>
<p><a href="themes/salutation-wp" title="Home">Salutation</a> is a premium WordPress theme created by <a href="" title="Parallelus Website" target="_blank">Parallelus</a>
 and available for purchase on ThemeForest. Developed using web 
standards such as HTML5, CSS3 and WordPress best practices. The theme is
 <a href="#" title="Visit BuddyPress Website" target="_blank">BuddyPress</a> ready with the necessary tools to create your own social network.</p>
</div>

<div class="col-1-4">
<h3 class="sectionTitle"><cufon style="width: 44px; height: 13px;" alt="What " class="cufon cufon-canvas"><canvas style="width: 55px; height: 14px; top: 0px; left: -1px;" height="14" width="55"></canvas><cufontext>What </cufontext></cufon><cufon style="width: 16px; height: 13px;" alt="is " class="cufon cufon-canvas"><canvas style="width: 27px; height: 14px; top: 0px; left: -1px;" height="14" width="27"></canvas><cufontext>is </cufontext></cufon><cufon style="width: 95px; height: 13px;" alt="BuddyPress?" class="cufon cufon-canvas"><canvas style="width: 104px; height: 14px; top: 0px; left: -1px;" height="14" width="104"></canvas><cufontext>BuddyPress?</cufontext></cufon></h3>
<p><a href="#" title="Visit BuddyPress Website" target="_blank">BuddyPress</a> is a <a href="http://wordpress.org/" title="Visit WordPress Website" target="_blank">WordPress</a> plugin to make your website a social network with community features like groups, forums, messaging, blogs and more.</p>
</div>

<div class="col-1-4 last">
<div>Follow us: <a oldtitle="Twitter" href="http://twitter.com/" target="_blank" class="tip">Twitter</a> | <a oldtitle="Buzz" href="http://www.google.com/buzz" target="_blank" class="tip">Buzz</a> | <a oldtitle="Facebook" href="https://www.facebook.com/" target="_blank" class="tip">Facebook</a></div>
</div>

<div class="clear"></div>

<div style="margin: 30px 0 0;">
<a href="" title="Parallelus Inc." target="_blank"><img src="images/logo-small-white.png" alt="Salutation - A Premium BuddyPress Theme" height="27" width="107"></a>
<p>Copyright © 2011 <a href="" title="Parallelus Inc." target="_blank">Parallelus</a>. All rights reserved.</p>
</div><div class="clear"></div></div></div>					</div>
							</div>
		</div>
	</div>
</footer>		
	</div> <!--! end of #Bottom -->
</div> <!--! end of #Wrapper -->


<div class="hidden">
	<div id="LoginPopup">
		<form class="loginForm" id="popupLoginForm" method="post" action="themes/salutation-wp/wp-login.php">
			<div id="loginBg"><div id="loginBgGraphic"></div></div>
			<div class="loginContainer">
				<h3><cufon style="width: 42px; height: 18px;" alt="Sign " class="cufon cufon-canvas"><canvas style="width: 58px; height: 19px; top: 1px; left: -1px;" height="19" width="58"></canvas><cufontext>Sign </cufontext></cufon><cufon style="width: 22px; height: 18px;" alt="in " class="cufon cufon-canvas"><canvas style="width: 37px; height: 19px; top: 1px; left: -1px;" height="19" width="37"></canvas><cufontext>in </cufontext></cufon><cufon style="width: 23px; height: 18px;" alt="to " class="cufon cufon-canvas"><canvas style="width: 39px; height: 19px; top: 1px; left: -1px;" height="19" width="39"></canvas><cufontext>to </cufontext></cufon><cufon style="width: 45px; height: 18px;" alt="your " class="cufon cufon-canvas"><canvas style="width: 61px; height: 19px; top: 1px; left: -1px;" height="19" width="61"></canvas><cufontext>your </cufontext></cufon><cufon style="width: 70px; height: 18px;" alt="account" class="cufon cufon-canvas"><canvas style="width: 84px; height: 19px; top: 1px; left: -1px;" height="19" width="84"></canvas><cufontext>account</cufontext></cufon></h3>
				<fieldset class="formContent">
					<legend>Account Login</legend>
					<div class="fieldContainer">
						<label for="ModalUsername">Username</label>
						<input id="ModalUsername" name="log" class="textInput" type="text">
					</div>
					<div class="fieldContainer">
						<label for="ModalPassword">Password</label>
						<input id="ModalPassword" name="pwd" class="textInput" type="password">
					</div>
				</fieldset>
			</div>
			<div class="formContent">
				<button type="submit" class="btn signInButton"><span>Sign in</span></button>
			</div>
			<div class="hr"></div>
			<div class="formContent">
				<a href="#" id="popupLoginForgotPswd">Forgot your password?</a>
			</div>
		</form>
	</div>
</div>

<!-- Generated in 0.362 seconds. (64 q) -->

	<script type="text/javascript" src="js/jscolor.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js"></script>
<script type="text/javascript" src="js/jquery_002.js"></script>
<script type="text/javascript" src="js/jquery_003.js"></script>
<div style="display: block; top: 195px;" id="ThemeStylePicker">
	<p>Top</p>
	<input value="CECCCC" style="background-color: rgb(206, 204, 204);" autocomplete="off" id="TopColorPicker" class="pickerInput">
	<p>Header</p>
	<input value="F2F0F0" style="background-color: rgb(242, 240, 240);" autocomplete="off" id="HeaderColorPicker" class="pickerInput">
	<p>Body</p>
	<input value="F2F0F0" style="background-color: rgb(242, 240, 240);" autocomplete="off" id="BodyColorPicker" class="pickerInput">
	<p>Middle</p>
	<input value="FAF9F9" style="background-color: rgb(250, 249, 249);" autocomplete="off" id="ContentColorPicker" class="pickerInput">
	<p>Footer</p>
	<input value="414B52" style="background-color: rgb(65, 75, 82);" autocomplete="off" id="FooterColorPicker" class="pickerInput">
	<a href="#" id="CloseThemeStylePicker">Close</a>
</div>
<script src="js/cufon.js"></script>
<script type="text/javascript">
	Cufon.replace
		('h1:not(.cta-title),h2:not(.cta-title),h3:not(.cta-title),h4:not(.cta-title),h5:not(.cta-title),h6:not(.cta-title)', {hover: true})
		('.widget .item-list .item-title', {hover: true });
	Cufon.now();
</script>

<script type="text/javascript">
		if ( jQuery('#MM ul') ) { ddsmoothmenu.init({ mainmenuid: "MM", orientation: "h", classname: "slideMenu", contentsource: "markup" }); }
	</script>
<script src="js/onLoad.js"></script>
</body></html>