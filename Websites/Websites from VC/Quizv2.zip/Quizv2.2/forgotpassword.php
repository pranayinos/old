<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html class=" js flexbox canvas canvastext no-webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms no-csstransforms3d csstransitions fontface video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths cufon-active cufon-ready" dir="ltr" lang="en-US"><!--<![endif]--><head><style type="text/css"></style>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><title>Forgot Password</title>

<link rel="shortcut icon" href="favicon.ico">
<link rel="apple-touch-icon-precomposed" href="apple-itouch-icon.png">

<script type="text/javascript"> 
	var fadeContent = 'all'; 
	var toolTips = 'class'; 
</script>

<link rel="stylesheet" type="text/css" href="css/base.css">
<link rel="stylesheet" type="text/css" href="css/buddypress.css">
<link rel="stylesheet" type="text/css" href="css/style-default.css">
<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css">
<link rel="stylesheet" type="text/css" href="css/colorbox.css">
<link rel="stylesheet" type="text/css" href="css/qtip.css">
<link rel="stylesheet" type="text/css" href="css/style-skin-1.css" id="SkinCSS">
<link rel="alternate" type="application/rss+xml" title="Salutation » Feed" href="themes/salutation-wp/feed/">
<link rel="alternate" type="application/rss+xml" title="Salutation » Comments Feed" href="themes/salutation-wp/comments/feed/">
<link rel="stylesheet" id="demo-colors-css-css" href="css/styles.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/widget-members.js"></script>
<script type="text/javascript" src="js/widget-groups.js"></script>
<script type="text/javascript" src="js/global.js"></script>
<script type="text/javascript" src="js/modernizr-1.js"></script>
<script type="text/javascript" src="js/swfobject.js"></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script src="Js/jquery-1.7.1.min.js"></script>
<script  src="Js/jqueryy.validate.min.js"></script>
<script>
function fun()
{
	$(".standard-form").validate({errorClass:'clas'});
}
</script>
	<style type="text/css">
	    .clas 
{color:red; } 
    </style><style type="text/css">cufon{text-indent:0!important;}@media screen,projection{cufon{display:inline!important;display:inline-block!important;position:relative!important;vertical-align:middle!important;font-size:1px!important;line-height:1px!important;}cufon cufontext{display:-moz-inline-box!important;display:inline-block!important;width:0!important;height:0!important;overflow:hidden!important;text-indent:-10000in!important;}cufon canvas{position:relative!important;}}@media print{cufon{padding:0!important;}cufon canvas{display:none!important;}}</style>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="themes/salutation-wp/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="themes/salutation-wp/wp-includes/wlwmanifest.xml"> 
<link rel="prev" title="Home Page: Sample 1" href="themes/salutation-wp/page-samples/home-page-sample-1/">
<meta name="generator" content="WordPress 3.3.1">
<link rel="canonical" href="themes/salutation-wp/register/">

	<script type="text/javascript">var ajaxurl = "themes/salutation-wp/wp-load.php";</script>

	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>

	<script type="text/javascript"> jQuery(document).ready( function() { jQuery("a.confirm").click( function() { if ( confirm( 'Are you sure?' ) ) return true; else return false; }); });</script>



<script>!window.jQuery && document.write(unescape('%3Cscript src="js/jquery-1.7.1.min.js"%3E%3C/script%3E'))</script>

<!--[if lte IE 8]>
<link rel="stylesheet" type="text/css" href="css/ie.css" />
<![endif]-->

<style type="text/css">
body, select, input, textarea {  font-family: Arial, Helvetica, Garuda, sans-serif; } </style> 
</head>

<body onLoad="fun()" class="registration register  style-skin-1"><div style="display: none;" id="cboxOverlay"></div><div class="" id="colorbox" style="padding-bottom: 48px; padding-right: 40px; display: none;"><div style="" id="cboxWrapper"><div style=""><div style="float: left;" id="cboxTopLeft"></div><div style="float: left;" id="cboxTopCenter"></div><div style="float: left;" id="cboxTopRight"></div></div><div style="clear: left;"><div style="float: left;" id="cboxMiddleLeft"></div><div style="float: left;" id="cboxContent"><div class="" style="width: 0px; height: 0px; overflow: hidden;" id="cboxLoadedContent"></div><div class="" style="" id="cboxLoadingOverlay"></div><div class="" style="" id="cboxLoadingGraphic"></div><div class="" style="" id="cboxTitle"></div><div class="" style="" id="cboxCurrent"></div><div class="" style="" id="cboxNext"></div><div class="" style="" id="cboxPrevious"></div><div class="" style="" id="cboxSlideshow"></div><div class="" style="" id="cboxClose"></div></div><div style="float: left;" id="cboxMiddleRight"></div></div><div style="clear: left;"><div style="float: left;" id="cboxBottomLeft"></div><div style="float: left;" id="cboxBottomCenter"></div><div style="float: left;" id="cboxBottomRight"></div></div></div><div style="position: absolute; width: 9999px; visibility: hidden; display: none;"></div></div>

<div style="background-image: none; background-color: rgb(242, 240, 240); color: rgb(0, 0, 0);" id="Wrapper">
	<div style="background-image: none; background-color: rgb(206, 204, 204); color: rgb(0, 0, 0); opacity: 1;" id="Top">
		<div class="clearfix">
		
			<div id="headerWrapper" style="background: transparent;">
	<div class="inner-1">
		<div class="inner-2">
		  <header>
			  <div id="MainHeader" class="pageWrapper clearfix">
					<h1 id="Logo"><a href="themes/salutation-wp"><img src="images/logo.png" alt="Salutation" class="default" height="40" width="140"></a></h1>
			  </div>
				
							</header>
			
							<div id="PageTop" class="showShadow">
					<div style="background-image: none; background-color: rgb(242, 240, 240); color: rgb(0, 0, 0);" id="HeaderInner" class="inner-1 pageWrapper">
						<div class="staticBlockWrapper ugc" style="background: transparent;"><div class="staticContent scid-1786"><div style="margin: -11px 0 -7px"><div class="breadcrumbs"><a href="themes/salutation-wp">Home</a> &nbsp;/&nbsp; Forgot Password</div></div><div class="clear"></div></div></div>					</div>
				</div>
					
		</div>
	</div>
</div>
			
		</div>
	</div> <!--! end of #Top -->
	
	<div style="opacity: 1;" id="Middle">
		<div class="pageWrapper theContent clearfix">
			<div style="background-image: none; background-color: rgb(250, 249, 249); color: rgb(0, 0, 0);" id="MiddleInner" class="inner-1">
				<div class="inner-2 contentMargin">
			
					<div id="page-right-sidebar_c1" class="clearfix">
	<div id="page-right-sidebar_c1_col-3-4_1" class="col-3-4 clearfix"><div class="i0 ugc">
	<div id="BP-Container">
		<div id="BP-Content">

				
			<div class="page" id="register-page">
	
				<form action="reset.php" name="reset_form" id="reset_form" class="standard-form" method="post" enctype="multipart/form-data">
	
					
					
					<h2><cufon style="width: 69px; height: 20px;" alt="Reset " class="cufon cufon-canvas"><canvas style="width: 86px; height: 21px; top: 1px; left: -2px;" height="21" width="86"></canvas><cufontext>Reset </cufontext></cufon><cufon style="width: 30px; height: 20px;" alt="your " class="cufon cufon-canvas"><canvas style="width: 47px; height: 21px; top: 1px; left: -2px;" height="21" width="47"></canvas><cufontext>your </cufontext></cufon><cufon style="width: 79px; height: 20px;" alt="Password" class="cufon cufon-canvas"><canvas style="width: 94px; height: 21px; top: 1px; left: -2px;" height="21" width="94"></canvas><cufontext>Password</cufontext></cufon></h2>
	
						
					<p>Reset your password easily, just fill in the fields below and we'll send a password reset link to your registered email.</p><!-- #basic-details-section -->
	
						
						
						
							
						<div class="register-section" id="profile-details-section">
	
							<h4><cufon style="width: 55px; height: 16px;" alt="Profile " class="cufon cufon-canvas"><canvas style="width: 69px; height: 17px; top: 1px; left: -1px;" height="17" width="69"></canvas><cufontext>Profile </cufontext></cufon><cufon style="width: 54px; height: 16px;" alt="Details" class="cufon cufon-canvas"><canvas style="width: 64px; height: 17px; top: 1px; left: -1px;" height="17" width="64"></canvas><cufontext>Details</cufontext></cufon></h4>
	
															
								
								<div class="editfield">
	
										
										<label for="field_1">Name (required)</label>
																				<input name="name" id="field_1" type="text" required>
										
										
										
										
										
										
										
										
									<p class="description"></p>
	
								</div>
	
								
								<div class="editfield">
	
										
										<label for="field_2">Email  (required)</label>
																				<input name="email" id="email" type="text" class="required email">	
										
										
										
										
										
										
										
										
									<p class="description"></p>
	
								</div>
	
								
								<div class="editfield">
								  <div class="editfield">
								    <label for="field_3">Confirm email	 (required)</label>
								    <input name="signup_password_confirm"  required id="signup_password_confirm" type="text" equalTo="#email">
								    <p class="description"></p>
							      </div>
								 
	
								</div>
	
								
							<input name="signup_profile_field_ids" id="signup_profile_field_ids" value="1,2,3" type="hidden">
	
								
						</div><!-- #profile-details-section -->
	
							
						
						
						
					<div class="submit">
						<input class="btn" name="Reset" id="signup_submit" value="Reset Password" type="submit">
					</div>
	
						
					<input id="_wpnonce" name="_wpnonce" value="6c87650c26" type="hidden"><input name="_wp_http_referer" value="/themes/salutation-wp/register/" type="hidden">	
					
					
					
				</form>
	
			</div>
	
				
		<script type="text/javascript">
			jQuery(document).ready( function() {
				if ( jQuery('div#blog-details').length && !jQuery('div#blog-details').hasClass('show') )
					jQuery('div#blog-details').toggle();
	
				jQuery( 'input#signup_with_blog' ).click( function() {
					jQuery('div#blog-details').fadeOut().toggle();
				});
			});
		</script>

		</div><!-- #content -->
	</div><!-- #container -->
</div></div> <!-- END id=page-right-sidebar_c1_col-3-4_1 class=col-3-4 -->
	<div id="page-right-sidebar_c1_col-1-4_2" class="col-1-4 clearfix last"><div class="i0 ugc"><div id="text-7" class="widget scg_widget default-page widget_text"><h4 class="widgetTitle"><cufon style="width: 67px; height: 13px;" alt="Random " class="cufon cufon-canvas"><canvas style="width: 78px; height: 14px; top: 0px; left: -1px;" height="14" width="78"></canvas><cufontext>Random </cufontext></cufon><cufon style="width: 81px; height: 13px;" alt="Portfolio " class="cufon cufon-canvas"><canvas style="width: 92px; height: 14px; top: 0px; left: -1px;" height="14" width="92"></canvas><cufontext>Portfolio </cufontext></cufon></h4>			<div class="textwidget">
<section class="content-post-list clearfix">
	<ol class="posts-list portfolio-list">
	
	
		<li class="portfolio-item clearfix" style="width: 200px; margin-right: 0;">
			<article id="post-1028" class="post-1028 page type-page status-publish hentry type-portfolio">
				<div style="height: 88px;" class="item-container">
					
					<div class="the-post-image">
						<a href="themes/salutation-wp/wp-content/uploads/2011/09/sample-image-5.jpg" class="popup cboxElement" title="Proin imperdiet adipiscing nisl" rel="portfolio_2wl58eq5o0cg"><figure><img src="images/sample-image-5-200x88.jpg" height="88" width="200"></figure></a>					</div>
					
							
				</div>

			</article>
		</li>
		
		
		<li class="portfolio-item clearfix" style="width: 200px; margin-right: 0;">
			<article id="post-1040" class="post-1040 page type-page status-publish hentry type-portfolio">
				<div style="height: 88px;" class="item-container">
					
					<div class="the-post-image">
						<a href="themes/salutation-wp/wp-content/uploads/2011/09/sample-image-7.jpg" class="popup cboxElement" title="Oauris arcu ipsum" rel="portfolio_2wl58eq5o0cg"><figure><img src="images/sample-image-7-200x88.jpg" height="88" width="200"></figure></a>					</div>
					
							
				</div>

			</article>
		</li>
		
		
		<li class="portfolio-item clearfix" style="width: 200px; margin-right: 0;">
			<article id="post-1038" class="post-1038 page type-page status-publish hentry type-portfolio">
				<div style="height: 88px;" class="item-container">
					
					<div class="the-post-image">
						<a href="themes/salutation-wp/wp-content/uploads/2011/09/sample-image-6.jpg" class="popup cboxElement" title="Cras consectetur ipsum" rel="portfolio_2wl58eq5o0cg"><figure><img src="images/sample-image-6-200x88.jpg" height="88" width="200"></figure></a>					</div>
					
							
				</div>

			</article>
		</li>
		
			
	</ol>
</section>


 </div>
		</div></div></div> <!-- END id=page-right-sidebar_c1_col-1-4_2 class=col-1-4 -->
</div> <!-- END id=page-right-sidebar_container_1 -->

			
				</div>
			</div>
		</div> <!--! end of .pageWrapper -->
	</div> <!--! end of #Middle -->
	
	<div style="opacity: 1;" id="Bottom">		

		<footer style="background: transparent;">
	<div style="background-image: none; background-color: rgb(65, 75, 82); color: rgb(255, 255, 255);" id="BottomInner" class="pageWrapper theContent clearfix">
		<div class="inner-1">
			<div class="inner-2">
									<div class="ugc clearfix">
						<div class="staticBlockWrapper ugc" style="background: transparent;"><div class="staticContent scid-1710">
<div class="col-1-2">
<h3 class="sectionTitle"><cufon style="width: 52px; height: 13px;" alt="About " class="cufon cufon-canvas"><canvas style="width: 63px; height: 14px; top: 0px; left: -1px;" height="14" width="63"></canvas><cufontext>About </cufontext></cufon><cufon style="width: 30px; height: 13px;" alt="The " class="cufon cufon-canvas"><canvas style="width: 41px; height: 14px; top: 0px; left: -1px;" height="14" width="41"></canvas><cufontext>The </cufontext></cufon><cufon style="width: 47px; height: 13px;" alt="Theme" class="cufon cufon-canvas"><canvas style="width: 54px; height: 14px; top: 0px; left: -1px;" height="14" width="54"></canvas><cufontext>Theme</cufontext></cufon></h3>
<p><a href="themes/salutation-wp" title="Home">Salutation</a> is a premium WordPress theme created by <a href="" title="Parallelus Website" target="_blank">Parallelus</a>
 and available for purchase on ThemeForest. Developed using web 
standards such as HTML5, CSS3 and WordPress best practices. The theme is
 <a href="#" title="Visit BuddyPress Website" target="_blank">BuddyPress</a> ready with the necessary tools to create your own social network.</p>
</div>

<div class="col-1-4">
<h3 class="sectionTitle"><cufon style="width: 44px; height: 13px;" alt="What " class="cufon cufon-canvas"><canvas style="width: 55px; height: 14px; top: 0px; left: -1px;" height="14" width="55"></canvas><cufontext>What </cufontext></cufon><cufon style="width: 16px; height: 13px;" alt="is " class="cufon cufon-canvas"><canvas style="width: 27px; height: 14px; top: 0px; left: -1px;" height="14" width="27"></canvas><cufontext>is </cufontext></cufon><cufon style="width: 95px; height: 13px;" alt="BuddyPress?" class="cufon cufon-canvas"><canvas style="width: 104px; height: 14px; top: 0px; left: -1px;" height="14" width="104"></canvas><cufontext>BuddyPress?</cufontext></cufon></h3>
<p><a href="#" title="Visit BuddyPress Website" target="_blank">BuddyPress</a> is a <a href="http://wordpress.org/" title="Visit WordPress Website" target="_blank">WordPress</a> plugin to make your website a social network with community features like groups, forums, messaging, blogs and more.</p>
</div>

<div class="col-1-4 last">
<div>Follow us: <a oldtitle="Twitter" href="http://twitter.com/" target="_blank" class="tip">Twitter</a> | <a oldtitle="Buzz" href="http://www.google.com/buzz" target="_blank" class="tip">Buzz</a> | <a oldtitle="Facebook" href="https://www.facebook.com/" target="_blank" class="tip">Facebook</a></div>
</div>

<div class="clear"></div>

<div style="margin: 30px 0 0;">
<a href="" title="Parallelus Inc." target="_blank"><img src="images/logo-small-white.png" alt="Salutation - A Premium BuddyPress Theme" height="27" width="107"></a>
<p>Copyright © 2011 <a href="" title="Parallelus Inc." target="_blank">Parallelus</a>. All rights reserved.</p>
</div><div class="clear"></div></div></div>					</div>
		  </div>
		</div>
	</div>
</footer>		
	</div> <!--! end of #Bottom -->
</div> <!--! end of #Wrapper -->


<div class="hidden">
	<div id="LoginPopup"></div>
</div>

<!-- Generated in 0.362 seconds. (64 q) -->

	<script type="text/javascript" src="js/jscolor.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js"></script>
<script type="text/javascript" src="js/jquery_002.js"></script>
<script type="text/javascript" src="js/jquery_003.js"></script><script src="js/cufon.js"></script>
<script type="text/javascript">
	Cufon.replace
		('h1:not(.cta-title),h2:not(.cta-title),h3:not(.cta-title),h4:not(.cta-title),h5:not(.cta-title),h6:not(.cta-title)', {hover: true})
		('.widget .item-list .item-title', {hover: true });
	Cufon.now();
</script>

<script type="text/javascript">
		if ( jQuery('#MM ul') ) { ddsmoothmenu.init({ mainmenuid: "MM", orientation: "h", classname: "slideMenu", contentsource: "markup" }); }
	</script>
<script src="js/onLoad.js"></script>


</body></html>