<?php
session_start();
				include("database.php");
				unset($_SESSION['sid']);
				unset($_SESSION['tid']);
				unset($_SESSION['set']);
				unset($_SESSION['qn']);
				unset($_SESSION['level']);
				unset($_SESSION['trueans']);
				unset($_SESSION['q_arr']);	
				
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html class=" js flexbox canvas canvastext no-webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms no-csstransforms3d csstransitions fontface video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths cufon-active cufon-ready" dir="ltr" lang="en-US"><!--<![endif]--><head><style type="text/css"></style>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><title>Compitition !!! check your intelligence now</title>

<link rel="shortcut icon" href="favicon.ico">
<link rel="apple-touch-icon-precomposed" href="#">

<script type="text/javascript"> 
	var fadeContent = 'all'; 
	var toolTips = 'class'; 
</script>

<link rel="stylesheet" type="text/css" href="css/base.css">
<link rel="stylesheet" type="text/css" href="css/buddypress.css">
<link rel="stylesheet" type="text/css" href="css/style-default.css">
<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css">
<link rel="stylesheet" type="text/css" href="css/colorbox.css">
<link rel="stylesheet" type="text/css" href="css/qtip.css">
<link rel="stylesheet" type="text/css" href="css/style-skin-1.css" id="SkinCSS">
<link rel="alternate" type="application/rss+xml" title="Salutation » Feed" href="#/feed/">
<link rel="alternate" type="application/rss+xml" title="Salutation » Comments Feed" href="#/comments/feed/">
<link rel="stylesheet" id="demo-colors-css-css" href="css/styles.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery_004.js"></script> 
<script type="text/javascript" src="js/widget-members.js"></script>
<script type="text/javascript" src="js/widget-groups.js"></script>
<script type="text/javascript" src="js/global.js"></script>
<script type="text/javascript" src="js/modernizr-1.js"></script>
<script type="text/javascript" src="js/swfobject.js"></script>
<script type="text/javascript" src="js/cufon-yui.js"></script><style type="text/css">cufon{text-indent:0!important;}@media screen,projection{cufon{display:inline!important;display:inline-block!important;position:relative!important;vertical-align:middle!important;font-size:1px!important;line-height:1px!important;}cufon cufontext{display:-moz-inline-box!important;display:inline-block!important;width:0!important;height:0!important;overflow:hidden!important;text-indent:-10000in!important;}cufon canvas{position:relative!important;}}@media print{cufon{padding:0!important;}cufon canvas{display:none!important;}}</style>

<meta name="generator" content="WordPress 3.3.1">

	<script type="text/javascript">var ajaxurl = "#/wp-load.php";</script>

	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>

	<script type="text/javascript"> jQuery(document).ready( function() { jQuery("a.confirm").click( function() { if ( confirm( 'Are you sure?' ) ) return true; else return false; }); });</script>

 

<script>!window.jQuery && document.write(unescape('%3Cscript src="/js/jquery-1.7.1.min.js"%3E%3C/script%3E'))</script>

<!--[if lte IE 8]>
<link rel="stylesheet" type="text/css" href="css/ie.css" />
<![endif]-->

<style type="text/css">
body, select, input, textarea {  font-family: Arial, Helvetica, Garuda, sans-serif; } </style> </head>

<body class="home-page home blog style-skin-1"><div style="display: none;" id="cboxOverlay"></div><div class="" id="colorbox" style="padding-bottom: 48px; padding-right: 40px; display: none;"><div style="" id="cboxWrapper"><div style=""><div style="float: left;" id="cboxTopLeft"></div><div style="float: left;" id="cboxTopCenter"></div><div style="float: left;" id="cboxTopRight"></div></div><div style="clear: left;"><div style="float: left;" id="cboxMiddleLeft"></div><div style="float: left;" id="cboxContent"><div class="" style="width: 0px; height: 0px; overflow: hidden;" id="cboxLoadedContent"></div><div class="" style="" id="cboxLoadingOverlay"></div><div class="" style="" id="cboxLoadingGraphic"></div><div class="" style="" id="cboxTitle"></div><div class="" style="" id="cboxCurrent"></div><div class="" style="" id="cboxNext"></div><div class="" style="" id="cboxPrevious"></div><div class="" style="" id="cboxSlideshow"></div><div class="" style="" id="cboxClose"></div></div><div style="float: left;" id="cboxMiddleRight"></div></div><div style="clear: left;"><div style="float: left;" id="cboxBottomLeft"></div><div style="float: left;" id="cboxBottomCenter"></div><div style="float: left;" id="cboxBottomRight"></div></div></div><div style="position: absolute; width: 9999px; visibility: hidden; display: none;"></div></div>

<div style="background-image: none; background-color: rgb(242, 240, 240); color: rgb(0, 0, 0);" id="Wrapper">
	<div style="background-image: none; background-color: rgb(206, 204, 204); color: rgb(0, 0, 0); opacity: 1;" id="Top">
		<div class="clearfix">
		
			<div id="headerWrapper" style="background: transparent;">
	<div class="inner-1">
		<div class="inner-2">
							<div id="TopPanel" class="clearfix">
					<div class="sections">
											<section id="4lct468lzl6o" class="topPanelSection primary-tab" style="display: none; ">
							<div class="ugc pageWrapper topPanelContent">
								<div id="text-11" class="widget scg_widget 4lct468lzl6o widget_text">			<div class="textwidget"><div class="col-1-3">
	<br><div class="clear"></div>
	
	<div class="textBox icon"><div class="icon48 icon-info"></div><div class="textContent"><h4 class="textBoxTitle"><cufon style="width: 48px; height: 16px;" alt="Need " class="cufon cufon-canvas"><canvas style="width: 62px; height: 17px; top: 1px; left: -1px;" height="17" width="62"></canvas>
	<cufontext>Need </cufontext></cufon><cufon style="width: 46px; height: 16px;" alt="Help?" class="cufon cufon-canvas"><canvas style="width: 56px; height: 17px; top: 1px; left: -1px;" height="17" width="56"></canvas>
	<cufontext>Help?</cufontext></cufon></h4><span class="theText">
		Etiam aliquam sem ac velit feugiat elementum. Nunc eu elit velit, nec 
vestibulum nibh. Curabitur ultrices, diam non ullamcorper blandit, nunc 
lacus ornare nisi, egestas rutrum magna est id nunc. Pellentesque 
imperdiet.
	</span></div></div>

	<div class="clear"></div>
</div>
<div class="col-1-3">
	<br><div class="clear"></div>
	
	<div class="textBox icon"><div class="icon48 icon-groups"></div><div class="textContent"><h4 class="textBoxTitle"><cufon style="width: 35px; height: 16px;" alt="The " class="cufon cufon-canvas"><canvas style="width: 48px; height: 17px; top: 1px; left: -1px;" height="17" width="48"></canvas>
	<cufontext>The </cufontext></cufon><cufon style="width: 71px; height: 16px;" alt="benefits " class="cufon cufon-canvas"><canvas style="width: 85px; height: 17px; top: 1px; left: -1px;" height="17" width="85"></canvas>
	<cufontext>benefits </cufontext></cufon><cufon style="width: 21px; height: 16px;" alt="of " class="cufon cufon-canvas"><canvas style="width: 35px; height: 17px; top: 1px; left: -1px;" height="17" width="35"></canvas>
	<cufontext>of </cufontext></cufon><cufon style="width: 109px; height: 16px;" alt="membership:" class="cufon cufon-canvas"><canvas style="width: 122px; height: 17px; top: 1px; left: -1px;" height="17" width="122"></canvas>
	<cufontext>membership:</cufontext></cufon></h4><span class="theText">
		Nullam eros mi, mollis in sollicitudin non, tincidunt sed enim. Sed et
 felis metus, rhoncus ornare nibh. Ut at magna leo. Suspendisse egestas 
est ac dolor imperdiet pretium. Lorem ipsum dolor sit amet, consectetur 
adipiscing elit.
	</span></div></div>

	<div class="clear"></div>
</div>
<div class="col-1-3 last">
	<div style="padding: 0 0 0 15px;">
		<h1><cufon style="width: 49px; height: 24px;" alt="Not " class="cufon cufon-canvas"><canvas style="width: 70px; height: 25px; top: 1px; left: -2px;" height="25" width="70"></canvas>
		<cufontext>Not </cufontext></cufon><cufon style="width: 21px; height: 24px;" alt="a " class="cufon cufon-canvas"><canvas style="width: 41px; height: 25px; top: 1px; left: -2px;" height="25" width="41"></canvas>
		<cufontext>a </cufontext></cufon><cufon style="width: 106px; height: 24px;" alt="member " class="cufon cufon-canvas"><canvas style="width: 126px; height: 25px; top: 1px; left: -2px;" height="25" width="126"></canvas>
		<cufontext>member </cufontext></cufon><cufon style="width: 46px; height: 24px;" alt="yet?" class="cufon cufon-canvas"><canvas style="width: 63px; height: 25px; top: 1px; left: -2px;" height="25" width="63"></canvas>
		<cufontext>yet?</cufontext></cufon></h1>
		<p>Signing up is easy and takes less and 3 minutes. Take a moment to 
create a user and get verified instantly. Register now to join the best 
community on the web.</p>
		
		<a href="register.php" class="btn impactBtn">Sign up instantly!</a>
	</div>
	<div class="clear"></div>
	<br>
</div></div>
		</div>							</div>
						</section>
                        
  <!-- Hidden Login Form ------------------------------------------------------------------------------------------------------- -->
                        
                        
                        
											<section id="4e4od16scosg" class="topPanelSection sign-in-icon" style="display: none;">
							<div class="ugc pageWrapper topPanelContent">
								<div id="text-10" class="widget scg_widget 4e4od16scosg widget_text">			<div class="textwidget"><div class="col-1-2">
	<h1><cufon style="width: 117px; height: 24px;" alt="Members " class="cufon cufon-canvas"><canvas style="width: 138px; height: 25px; top: 1px; left: -2px;" height="25" width="138"></canvas>
	<cufontext>Members </cufontext></cufon><cufon style="width: 55px; height: 24px;" alt="Sign " class="cufon cufon-canvas"><canvas style="width: 76px; height: 25px; top: 1px; left: -2px;" height="25" width="76"></canvas>
	<cufontext>Sign </cufontext></cufon><cufon style="width: 23px; height: 24px;" alt="In" class="cufon cufon-canvas"><canvas style="width: 35px; height: 25px; top: 1px; left: -2px;" height="25" width="35"></canvas>
	<cufontext>In</cufontext></cufon></h1>
	<p>Sign in to start taking online exam for various subject of interest.</p>
	<form class="publicForm" method="post" action="login.php">
		<div class="col-1-3">
			<div class="fieldContainer">
				<label for="loginid" class="formTitle">Email</label>
				<input id="loginid" name="loginid" class="textInput" style="width:90%" type="text" required>
			</div>
		</div>
		<div class="col-1-3">
			<div class="fieldContainer">
				<label for="pass" class="formTitle">Password</label>
				<input id="pass" name="pass" class="textInput" style="width:90%" type="password" required>
				 <a href="forgotpassword.php">forgot password ?</a>
            </div>
		</div>
		<div class="col-1-3">
			<br>
			<button type="submit" class="btn black" name="submit"><span>Sign in</span></button>
		</div>
	</form>
    <div style="float:left"> <?php
									if(isset($_GET['try']))
									{
									$try=$_GET['try'];
									if($try==0)
									{
										echo "Incorrect username or password";
									}
										 unset($_GET['try']);
									}
									?></div>
    
    <!-- end hidden login form ---------------------------------------------------------------------------------------------- -->

	<div class="clear"></div>
	<br><br>
</div>
<div class="col-1-4">
	<br><div class="clear"></div>
	<h4><cufon style="width: 72px; height: 16px;" alt="Member " class="cufon cufon-canvas"><canvas style="width: 85px; height: 17px; top: 1px; left: -1px;" height="17" width="85"></canvas>
	<cufontext>Member </cufontext></cufon><cufon style="width: 81px; height: 16px;" alt="Resources" class="cufon cufon-canvas"><canvas style="width: 91px; height: 17px; top: 1px; left: -1px;" height="17" width="91"></canvas>
	<cufontext>Resources</cufontext></cufon></h4>

	
		<ul class="icon-list " style="margin-left: 20px;">
			<li><div class="icon16 iconSymbol check"></div><a href="#">Getting Started Guide</a></li>
			<li><div class="icon16 iconSymbol check"></div><a href="#">Author Rules and Regulations</a></li>
			<li><div class="icon16 iconSymbol check"></div><a href="#">Frequently Asked Questions</a></li>
			</ul>
	

	<br><div class="clear"></div>
</div>
<div class="col-1-4 last">
	<br><div class="clear"></div>
	<h4><cufon style="width: 96px; height: 16px;" alt="Community " class="cufon cufon-canvas"><canvas style="width: 110px; height: 17px; top: 1px; left: -1px;" height="17" width="110"></canvas>
	<cufontext>Community </cufontext></cufon><cufon style="width: 41px; height: 16px;" alt="Tools" class="cufon cufon-canvas"><canvas style="width: 52px; height: 17px; top: 1px; left: -1px;" height="17" width="52"></canvas>
	<cufontext>Tools</cufontext></cufon></h4>

	
		<ul class="icon-list " style="margin-left: 20px;">
			<li><div class="icon16 iconSymbol plus"></div><a href="#">Top Contributors "Wall of Fame"</a></li>
			<li><div class="icon16 iconSymbol plus"></div><a href="#">Awards and Recognitions</a></li>
			<li><div class="icon16 iconSymbol plus"></div><a href="#">Recently Featured Articles</a></li>
			</ul>
	

	<br><div class="clear"></div>
</div></div>
		</div>							</div>
						</section>
										</div>
					<ul class="section-tabs pageWrapper">
					<li><a href="#4lct468lzl6o" id="Section-Tab-4lct468lzl6o" class="sectionTab primary-tab" style="">REGISTER</a></li><li><a href="#4e4od16scosg" id="Section-Tab-4e4od16scosg" class="sectionTab sign-in-icon" style="">SIGN IN</a></li>					</ul>
				</div>
							<header>
				<div id="MainHeader" class="pageWrapper clearfix">
					<h1 id="Logo"><a href="#"><img src="images/logo.png" alt="Salutation" class="default" height="40" width="140"></a></h1>
			
					<div id="MainMenu">
						<div class="inner-1">
							<div class="inner-2">
								<nav>
								
									<div id="MM" class="slideMenu">
										<ul id="menu-main-menu" class="menu"><li style="z-index: 300;" id="menu-item-2990" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2990"><a class="hasSubMenu" href="#">Styles<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li id="menu-item-2991" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2991"><a href="/themes/salutation-wp/?style=1">Light</a></li>
	<li id="menu-item-2992" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2992"><a href="/themes/salutation-wp/?style=2">Dark</a></li>
	<li id="menu-item-3373" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3373"><a href="/themes/salutation-wp/?style=3">Purple</a></li>
</ul>
</li>
<li style="z-index: 299;" id="menu-item-3088" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3088"><a class="hasSubMenu" href="#">Features<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li style="z-index: 298;" id="menu-item-2645" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2645"><a href="#">Page Layouts<span class="subRight"></span></a>
	<ul style="display: none; top: 0px; visibility: visible;" class="sub-menu">
		<li id="menu-item-2891" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2891"><a href="#/page-samples/page-left-sidebar/">Page: Sidebar Left</a></li>
		<li id="menu-item-2890" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2890"><a href="#/page-samples/page-right-sidebar/">Page: Sidebar Right</a></li>
		<li id="menu-item-2889" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2889"><a href="#/page-samples/page-graphic-header/">Page: Graphic Header</a></li>
		<li id="menu-item-3238" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3238"><a href="#/page-samples/page-slide-show-header/">Page: Slide Show Header</a></li>
		<li id="menu-item-2888" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2888"><a href="#/page-samples/page-with-slogan/">Page: Slogan (top banner)</a></li>
	</ul>
</li>
	<li style="z-index: 297;" id="menu-item-3334" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3334"><a href="#">Home Pages<span class="subRight"></span></a>
	<ul style="display: none; top: 0px; visibility: visible;" class="sub-menu">
		<li id="menu-item-3337" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3337"><a title="Create any home page layout with the drag-and-drop Layout Generator." href="#/page-samples/home-page-sample-1/">Home Page: Another Sample</a></li>
	</ul>
</li>
	<li style="z-index: 296;" id="menu-item-3089" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3089"><a href="#/theme-features/">Admin<span class="subRight"></span></a>
	<ul style="display: none; top: 0px; visibility: visible;" class="sub-menu">
		<li id="menu-item-3090" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3090"><a href="#/theme-features/layout-manager/">Layout Manager</a></li>
		<li id="menu-item-3091" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3091"><a href="#/theme-features/blog-settings/">Blog Settings</a></li>
		<li id="menu-item-3092" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3092"><a href="#/theme-features/contact-form/">Contact Forms</a></li>
		<li id="menu-item-3112" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3112"><a href="#/theme-features/slide-show/">Slide Show</a></li>
	</ul>
</li>
</ul>
</li>
<li style="z-index: 295;" id="menu-item-1825" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1825"><a class="hasSubMenu" href="#/blog/">Blog<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li id="menu-item-2432" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2432"><a href="#/blog/">Blog: Right Sidebar</a></li>
	<li id="menu-item-3118" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3118"><a href="#/blog/blog-left-sidebar/">Blog: Left Sidebar</a></li>
	<li id="menu-item-3131" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3131"><a href="#/blog/blog-3-column/">Blog: 3 Column</a></li>
	<li id="menu-item-2433" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2433"><a href="#/blog/blog-layout-samples/">Blog: Post Variations</a></li>
	<li id="menu-item-3121" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-3121"><a href="#/blog/2011/04/13/you-think-water-moves-fast/">Single Post: Right Sidebar</a></li>
	<li id="menu-item-3120" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-3120"><a href="#/blog/2011/03/19/airspeed-velocity-of-a-swallow/">Single Post: Left Sidebar</a></li>
	<li id="menu-item-3126" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-3126"><a href="#/blog/2011/03/05/when-do-spiders-sleep/">Single Post: 3 Column</a></li>
</ul>
</li>
<li style="z-index: 294;" id="menu-item-1826" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1826"><a class="hasSubMenu" href="#/portfolio/">Portfolio<span class="subDown"></span></a>

<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li style="z-index: 293;" id="menu-item-1828" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1828"><a href="#/portfolio/">Portfolio: Images<span class="subRight"></span></a>
	<ul style="display: none; top: 0px; visibility: visible;" class="sub-menu">
		<li id="menu-item-2650" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2650"><a href="#/portfolio/sample-portfolio-2-column/">2 Column</a></li>
		<li id="menu-item-2651" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2651"><a href="#/portfolio/sample-portfolio-3-column/">3 Column</a></li>
		<li id="menu-item-3152" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3152"><a href="#/portfolio/sample-portfolio-4-column/">4 Column</a></li>
		<li id="menu-item-3160" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3160"><a href="#/portfolio/sample-portfolio-5-column/">5 Column</a></li>
		<li id="menu-item-3166" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3166"><a href="#/portfolio/sample-portfolio-5-column-sidebar-left/">5 Column: Sidebar Left</a></li>
		<li id="menu-item-2652" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2652"><a href="#/portfolio/sample-portfolio-5-column-with-sidebar/">5 Column: Sidebar Right</a></li>
	</ul>
</li>
	<li id="menu-item-1829" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1829"><a href="#/portfolio/video-portfolio/">Portfolio: Videos</a></li>
	<li id="menu-item-1827" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1827"><a href="#/portfolio/gallery/">Gallery</a></li>
</ul>
</li>
<li style="z-index: 292;" id="menu-item-2654" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2654"><a class="hasSubMenu" href="#/activity/">BuddyPress<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li id="menu-item-3371" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3371"><a href="#/activity/">Activity</a></li>
	<li id="menu-item-3372" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3372"><a href="#/members/">Members</a></li>
	<li id="menu-item-3370" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3370"><a href="#/groups/">Groups</a></li>
	<li id="menu-item-3369" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3369"><a href="#/forums/">Forums</a></li>
	<li id="menu-item-3368" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3368"><a href="#/blogs/">Blogs</a></li>
</ul>
</li>
<li style="z-index: 291;" id="menu-item-2206" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2206"><a class="hasSubMenu" href="#">Shortcodes<span class="subDown"></span></a>
<ul style="display: none; top: 31px; visibility: visible;" class="sub-menu">
	<li id="menu-item-1807" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1807"><a href="#/shortcodes/images/">Images Styles</a></li>
	<li id="menu-item-1810" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1810"><a href="#/shortcodes/buttons/">Button Styles</a></li>
	<li id="menu-item-1812" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1812"><a href="#/shortcodes/icons-and-lists/">Icons and Lists</a></li>
	<li id="menu-item-1813" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1813"><a href="#/shortcodes/boxes-and-containers/">Quotes and Text Boxes</a></li>
	<li id="menu-item-1850" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1850"><a href="#/shortcodes/tabs-and-toggles/">Tabs and Toggles</a></li>
	<li id="menu-item-1849" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1849"><a href="#/shortcodes/pricing-table/">Pricing Tables</a></li>
	<li id="menu-item-1815" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1815"><a href="#/shortcodes/layout-columns-and-dividers/">Columns and Dividers</a></li>
	<li id="menu-item-1817" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1817"><a href="#/shortcodes/blog/">Blog Posts</a></li>
	<li id="menu-item-1819" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1819"><a href="#/shortcodes/portfolio/">Portfolio and Gallery</a></li>
	<li id="menu-item-1820" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1820"><a href="#/shortcodes/contact-form/">Contact Forms</a></li>
	<li id="menu-item-1823" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1823"><a href="#/shortcodes/slide-show/">Slide shows</a></li>
	<li id="menu-item-1824" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1824"><a href="#/shortcodes/miscellaneous/">Other Shortcodes</a></li>
</ul>
</li>
<li id="menu-item-1830" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1830"><a href="#/contact/">Contact</a></li>
<li style="z-index: 290;" id="menu-item-2466" class="-function-is-user-logged-in menu-item menu-item-type-custom menu-item-object-custom menu-item-2466"><a class="hasSubMenu cboxElement" href="#LoginPopup">Sign in<span class="subDown"></span></a>
<ul style="top: 31px; visibility: visible; left: -138px; width: 204px; display: none;" class="sub-menu">
	<li id="menu-item-2653" class="-function-is-user-logged-in menu-item menu-item-type-custom menu-item-object-custom menu-item-2653"><a class="cboxElement" href="#LoginPopup">Account sign in</a></li>
	<li id="menu-item-3367" class="-function-is-user-logged-in menu-item menu-item-type-post_type menu-item-object-page menu-item-3367"><a href="#/register/">Register for an account</a></li>
</ul>
</li>
</ul>										<div style="clear:left"></div>
									</div>
																						
								</nav>
							</div>
						</div>
					</div>
			
				</div>
				
							</header>
			
							<div id="PageTop" class="showShadow">
					<div style="background-image: none; background-color: rgb(242, 240, 240); color: rgb(0, 0, 0);" id="HeaderInner" class="inner-1 pageWrapper">
							<section class="slideShow" style="height: 360px;"><div style="position: relative; width: 972px; height: 360px;" id="SS-1-1"><div style="width: 972px; height: 360px; overflow: hidden; position: absolute; top: 0px; left: 0px; display: none; z-index: 6; opacity: 0;"><div class="slide imageSlide"><img src="images/demo-slide-1.jpg"></div></div><div style="width: 972px; height: 360px; overflow: hidden; position: absolute; top: 0px; left: 0px; display: none; z-index: 6; opacity: 0;"><div class="slide imageSlide"><img src="images/demo-slide-2.jpg"></div></div><div style="width: 972px; height: 360px; overflow: hidden; position: absolute; top: 0px; left: 0px; display: none; z-index: 6; opacity: 0;"><div class="slide imageSlide"><img src="images/demo-slide-3.jpg"></div></div><div style="width: 972px; height: 360px; overflow: hidden; position: absolute; top: 0px; left: 0px; display: none; z-index: 6; opacity: 0;"><div class="slide imageSlide"><img src="images/demo-slide-4.jpg"></div></div><div style="width: 972px; height: 360px; overflow: hidden; position: absolute; top: 0px; left: 0px; display: block; z-index: 7; opacity: 1;"><div class="slide imageSlide"><img src="images/demo-slide-5.jpg"></div></div><div style="width: 972px; height: 360px; overflow: hidden; position: absolute; top: 0px; left: 0px; display: none; z-index: 6; opacity: 0;"><div class="slide imageSlide"><img src="images/demo-slide-6.jpg"></div></div></div> <!-- END "SS-1-1" -->	</section> <!-- END id="SlideShow" --><div id="SS-1-1_nav" class="slideShowPager"><a class="" href="#">1</a><a class="" href="#">2</a><a class="" href="#">3</a><a class="" href="#">4</a><a class="activeSlide" href="#">5</a><a class="" href="#">6</a></div><script type="text/javascript"> jQuery(document).ready(function($) { $("#SS-1-1").cycle({ fx:"fade,fade,fade,fade,fade,fade",timeout:5000,speed:800,pause:0,randomizeEffects:0, pager:"#SS-1-1_nav"});SS_demo = $("#SS-1-1");}); </script>					</div>
				</div>
					
		</div>
	</div>
</div>
			
		</div>
	</div> <!--! end of #Top -->
	
	<div style="opacity: 1;" id="Middle">
		<div class="pageWrapper theContent clearfix">
			<div style="background-image: none; background-color: rgb(250, 249, 249); color: rgb(0, 0, 0);" id="MiddleInner" class="inner-1">
				<div class="inner-2 contentMargin">
			
					<div id="home-page-layout_c1" class="clearfix">
	<div id="home-page-layout_c1_col-1-1_1" class="col-1-1 clearfix"><div class="i0 ugc"><div class="staticBlockWrapper ugc" style="background: transparent;"><div class="staticContent scid-2753"><div style="float:left; margin: 8px 0 12px;">
	<div id="HomeHeadline"><img src="images/home-headline.png" class="left" alt="Join » Share » Connect!" height="55" width="715"></div>
</div>
<div style="margin:19px 0 0 -14px; float:left;">
	<a href="register.php" class="btn impactBtn">Sign Up Now!</a>
</div>
<div class="clear"></div>

<hr style="margin-bottom: 45px">
<div class="clear"></div></div></div></div></div> <!-- END id=home-page-layout_c1_col-1-1_1 class=col-1-1 -->
</div> <!-- END id=home-page-layout_container_1 -->

<div id="home-page-layout_c2" class="clearfix">
	<div id="home-page-layout_c2_col-2-3_1" class="col-2-3 clearfix"><div class="i0 ugc"><div class="page ugc"><div style="margin-top: -15px;">
<div class="col-1-2">
	<div style="padding: 0 15px;">
		<div class="textBox icon"><div class="icon48 icon-groups"></div><div class="textContent"><h4 class="textBoxTitle"><cufon style="width: 36px; height: 16px;" alt="Join " class="cufon cufon-canvas"><canvas style="width: 49px; height: 17px; top: 1px; left: -1px;" height="17" width="49"></canvas>
		<cufontext>Join </cufontext></cufon><cufon style="width: 15px; height: 16px;" alt="a " class="cufon cufon-canvas"><canvas style="width: 28px; height: 17px; top: 1px; left: -1px;" height="17" width="28"></canvas>
		<cufontext>a </cufontext></cufon><cufon style="width: 69px; height: 16px;" alt="Group... " class="cufon cufon-canvas"><canvas style="width: 83px; height: 17px; top: 1px; left: -1px;" height="17" width="83"></canvas>
		<cufontext>Group... </cufontext></cufon><cufon style="width: 22px; height: 16px;" alt="or " class="cufon cufon-canvas"><canvas style="width: 36px; height: 17px; top: 1px; left: -1px;" height="17" width="36"></canvas>
		<cufontext>or </cufontext></cufon><cufon style="width: 10px; height: 16px;" alt="4" class="cufon cufon-canvas"><canvas style="width: 19px; height: 17px; top: 1px; left: -1px;" height="17" width="19"></canvas>
		<cufontext>4</cufontext></cufon></h4><span class="theText">
			Find common interests and meet new friends in the groups. Join the ones that appeal to what you like.
		</span></div></div>
	</div>
</div>

<div class="col-1-2 last">
	<div style="padding: 0 15px;">
		<div class="textBox icon"><div class="icon48 icon-wp"></div><div class="textContent"><h4 class="textBoxTitle"><cufon style="width: 44px; height: 16px;" alt="Start " class="cufon cufon-canvas"><canvas style="width: 58px; height: 17px; top: 1px; left: -1px;" height="17" width="58"></canvas>
		<cufontext>Start </cufontext></cufon><cufon style="width: 36px; height: 16px;" alt="and " class="cufon cufon-canvas"><canvas style="width: 50px; height: 17px; top: 1px; left: -1px;" height="17" width="50"></canvas>
		<cufontext>and </cufontext></cufon><cufon style="width: 84px; height: 16px;" alt="Awesome " class="cufon cufon-canvas"><canvas style="width: 98px; height: 17px; top: 1px; left: -1px;" height="17" width="98"></canvas>
		<cufontext>Awesome </cufontext></cufon><cufon style="width: 36px; height: 16px;" alt="Blog" class="cufon cufon-canvas"><canvas style="width: 45px; height: 17px; top: 1px; left: -1px;" height="17" width="45"></canvas>
		<cufontext>Blog</cufontext></cufon></h4><span class="theText">
			Create a blog in the community to share your thoughts and ideas. Post articles, images and more.
		</span></div></div>
	</div>
</div>

<div class="clear"></div>

<div class="col-1-2">
	<div style="padding: 0 15px;">
		<div class="textBox icon"><div class="icon48 icon-comment"></div><div class="textContent"><h4 class="textBoxTitle"><cufon style="width: 46px; height: 16px;" alt="Have " class="cufon cufon-canvas"><canvas style="width: 60px; height: 17px; top: 1px; left: -1px;" height="17" width="60"></canvas>
		<cufontext>Have </cufontext></cufon><cufon style="width: 15px; height: 16px;" alt="a " class="cufon cufon-canvas"><canvas style="width: 28px; height: 17px; top: 1px; left: -1px;" height="17" width="28"></canvas>
		<cufontext>a </cufontext></cufon><cufon style="width: 87px; height: 16px;" alt="Discussion" class="cufon cufon-canvas"><canvas style="width: 95px; height: 17px; top: 1px; left: -1px;" height="17" width="95"></canvas>
		<cufontext>Discussion</cufontext></cufon></h4><span class="theText">
			Start a forum topic or comment on someone elses. Share ideas and get community feedback. 
		</span></div></div>
	</div>
</div>

<div class="col-1-2 last">
	<div style="padding: 0 15px;">
		<div class="textBox icon"><div class="icon48 icon-shuffle"></div><div class="textContent"><h4 class="textBoxTitle"><cufon style="width: 51px; height: 16px;" alt="Share " class="cufon cufon-canvas"><canvas style="width: 65px; height: 17px; top: 1px; left: -1px;" height="17" width="65"></canvas>
		<cufontext>Share </cufontext></cufon><cufon style="width: 41px; height: 16px;" alt="with " class="cufon cufon-canvas"><canvas style="width: 54px; height: 17px; top: 1px; left: -1px;" height="17" width="54"></canvas>
		<cufontext>with </cufontext></cufon><cufon style="width: 61px; height: 16px;" alt="Friends" class="cufon cufon-canvas"><canvas style="width: 71px; height: 17px; top: 1px; left: -1px;" height="17" width="71"></canvas>
		<cufontext>Friends</cufontext></cufon></h4><span class="theText">
			Make status updates to your friends and more with posts, images, videos and links.
		</span></div></div>
	</div>
</div>
</div>

<div class="clear"></div>
<div class="clear"></div>

<h3 class="sectionTitle"><cufon style="width: 54px; height: 13px;" alt="What’s " class="cufon cufon-canvas"><canvas style="width: 65px; height: 14px; top: 0px; left: -1px;" height="14" width="65"></canvas>
<cufontext>What’s </cufontext></cufon><cufon style="width: 32px; height: 13px;" alt="New" class="cufon cufon-canvas"><canvas style="width: 34px; height: 14px; top: 0px; left: -1px;" height="14" width="34"></canvas>
<cufontext>New</cufontext></cufon></h3>
<div class="clear"></div>
		<div id="BP-Container">
			<div id="BP-Content">
	
	
	
					
				<div class="activity">
					


		<noscript>
		<div class="pagination">
			<div class="pag-count">Viewing item 1 to 4 (of 42 items)</div>
			<div class="pagination-links"><span class='page-numbers current'>1</span>
<a class='page-numbers' href='/themes/salutation-wp/?acpage=2'>2</a>
<span class="page-numbers dots">&hellip;</span>
<a class='page-numbers' href='/themes/salutation-wp/?acpage=11'>11</a>
<a class="next page-numbers" href="/themes/salutation-wp/?acpage=2">&rarr;</a></div>
		</div>
	</noscript>

			<ul id="activity-stream" class="activity-list item-list">
	
	
		

<li class="xprofile new_member mini activity-li item-li" id="activity-1785">
	<article>
		<div class="activity-content item-container no-inner-content">
			<div class="item-content" id="ytivitca-1785">
							
				<header class="comment-header">
					
					<div class="activity-avatar">
						<a href="#/members/lyndaryan/">
							<div class="avatar" style="background-image: url('../images/bpfull-35x35.jpg'); "></div>						</a>
					</div>
					
					<div class="date">1 minute ago</div>
					
									
					<h2 class="poster-name"><a href="#/members/lyndaryan/" title="Go to Lynda Ryan's member page."><cufon style="width: 64px; height: 20px;" alt="Lynda " class="cufon cufon-canvas"><canvas style="width: 81px; height: 21px; top: 1px; left: -2px;" height="21" width="81"></canvas>
					<cufontext>Lynda </cufontext></cufon><cufon style="width: 48px; height: 20px;" alt="Ryan" class="cufon cufon-canvas"><canvas style="width: 58px; height: 21px; top: 1px; left: -2px;" height="21" width="58"></canvas>
					<cufontext>Ryan</cufontext></cufon></a></h2>
					
					<div class="activity-meta item-meta activity-header-info">
			
												
												
						<div class="activity-action"><p><a href="#/members/lyndaryan/" title="Lynda Ryan">Lynda Ryan</a> became a registered member <a href="#/activity/p/1785/" class="view activity-time-since" title="View Discussion"><span class="time-since">1 minute ago</span></a></p>
</div>
						
					</div>					
					
				</header>
				
						
						
				<footer class="activity-footer item-footer">
					
														
				</footer>
			
			</div>
		</div>
	
			
					<div style="display: none;" class="activity-replies item-container">
				<div class="item-content">
					<div class="activity-comments">
				
									
												
					</div>
				</div>
			</div>
			
			</article>

</li>


	
		

<li class="friends friendship_created mini activity-li item-li" id="activity-1701">
	<article>
		<div class="activity-content item-container no-inner-content">
			<div class="item-content" id="ytivitca-1701">
							
				<header class="comment-header">
					
					<div class="activity-avatar">
						<a href="#/members/jangkar/">
							<div class="avatar" style="background-image: url('../images/bpfull-35x35.jpg'); "></div>						</a>
					</div>
					
					<div class="date">1 year, 8 months ago</div>
					
									
					<h2 class="poster-name"><a href="#/members/jangkar/" title="Go to jangkarjeruji's member page."><cufon style="width: 121px; height: 20px;" alt="jangkarjeruji" class="cufon cufon-canvas"><canvas style="width: 138px; height: 21px; top: 1px; left: -2px;" height="21" width="138"></canvas>
					<cufontext>jangkarjeruji</cufontext></cufon></a></h2>
					
					<div class="activity-meta item-meta activity-header-info">
			
												
												
						<div class="activity-action"><p><a href="#/members/jangkar/" title="jangkarjeruji">jangkarjeruji</a> and <a href="#/members/tqueck/" title="Thomas">Thomas</a> are now friends <a href="#/activity/p/1701/" class="view activity-time-since" title="View Discussion"><span class="time-since">1 year, 8 months ago</span></a></p>
</div>
						
					</div>					
					
				</header>
				
						
						
				<footer class="activity-footer item-footer">
					
														
				</footer>
			
			</div>
		</div>
	
			
					<div style="display: none;" class="activity-replies item-container">
				<div class="item-content">
					<div class="activity-comments">
				
									
												
					</div>
				</div>
			</div>
			
			</article>

</li>


	
		

<li class="profile new_member mini activity-li item-li" id="activity-1610">
	<article>
		<div class="activity-content item-container no-inner-content">
			<div class="item-content" id="ytivitca-1610">
							
				<header class="comment-header">
					
					<div class="activity-avatar">
						<a href="#/members/fepreve/">
							<div class="avatar" style="background-image: url('#?d=../images/avatar-2-35x35.png&amp;s=35'); "></div>						</a>
					</div>
					
					<div class="date">1 year, 8 months ago</div>
					
									
					<h2 class="poster-name"><a href="#/members/fepreve/" title="Go to Fernanda's member page."><cufon style="width: 93px; height: 20px;" alt="Fernanda" class="cufon cufon-canvas"><canvas style="width: 104px; height: 21px; top: 1px; left: -2px;" height="21" width="104"></canvas>
					<cufontext>Fernanda</cufontext></cufon></a></h2>
					
					<div class="activity-meta item-meta activity-header-info">
			
												
												
						<div class="activity-action"><p><a href="#/members/fepreve/" title="Fernanda">Fernanda</a> became a registered member <a href="#/activity/p/1610/" class="view activity-time-since" title="View Discussion"><span class="time-since">1 year, 8 months ago</span></a></p>
</div>
						
					</div>					
					
				</header>
				
						
						
				<footer class="activity-footer item-footer">
					
														
				</footer>
			
			</div>
		</div>
	
			
					<div style="display: none;" class="activity-replies item-container">
				<div class="item-content">
					<div class="activity-comments">
				
									
												
					</div>
				</div>
			</div>
			
			</article>

</li>


	
		

<li class="groups new_forum_post activity-li item-li" id="activity-1556">
	<article>
		<div class="activity-content item-container ">
			<div class="item-content" id="ytivitca-1556">
							
				<header class="comment-header">
					
					<div class="activity-avatar">
						<a href="#/members/udiner/">
							<div class="avatar" style="background-image: url('../images/bpfull-35x35.jpg'); "></div>						</a>
					</div>
					
					<div class="date">1 year, 8 months ago</div>
					
									
					<h2 class="poster-name"><a href="#/members/udiner/" title="Go to farave's member page."><cufon style="width: 61px; height: 20px;" alt="farave" class="cufon cufon-canvas"><canvas style="width: 72px; height: 21px; top: 1px; left: -2px;" height="21" width="72"></canvas>
					<cufontext>farave</cufontext></cufon></a></h2>
					
					<div class="activity-meta item-meta activity-header-info">
			
												
												
						<div class="activity-action"><p><a href="#/members/udiner/" title="farave">farave</a> Posted on: <a href="#/groups/web-experts/forum/topic/fdddddddd/">Lovely, absolutely lovely <img src="images/icon_smile.gif" alt=":)" class="wp-smiley"> </a> in <a href="#/groups/web-experts/">Web Experts</a>: <a href="#/groups/web-experts/forum/topic/fdddddddd/#post-112" class="view activity-time-since" title="View Discussion"><span class="time-since">1 year, 8 months ago</span></a></p>
</div>
						
					</div>					
					
				</header>
				
									<div class="activity-inner">
						<p>wow…         beutiful</p>
					</div>
						
						
				<footer class="activity-footer item-footer">
					
														
				</footer>
			
			</div>
		</div>
	
			
			
			</article>

</li>


	
	
			</ul>
	


<form action="#" name="activity-loop-form" id="activity-loop-form" method="post">
	<input id="_wpnonce_activity_filter" name="_wpnonce_activity_filter" value="8faa0ae11a" type="hidden"><input name="_wp_http_referer" value="/themes/salutation-wp/" type="hidden"></form>

<script type="text/javascript">
/* Fix for BP default "load more" */
if (jq) {

	// remove the default BP click event
	jq('ul.activity-list li.load-more a').unbind('click'); 
	// Assign a new click behavior for 'load more' (again, necessary because of dumb references to containers like "#content")
	jq('ul.activity-list li.load-more a').click(function() {
		$parent = jq(this).parent('li.load-more');
		$parent.addClass('loading');

		if ( null == jq.cookie('bp-activity-oldestpage') )
			jq.cookie('bp-activity-oldestpage', 1, {path: '/'} );
	
		var oldest_page = ( jq.cookie('bp-activity-oldestpage') * 1 ) + 1;
	
		jq.post( ajaxurl, {
			action: 'activity_get_older_updates',
			'cookie': encodeURIComponent(document.cookie),
			'page': oldest_page
		},
		function(response) {
			$parent.removeClass('loading');
			jq.cookie( 'bp-activity-oldestpage', oldest_page, {path: '/'} );
			jq("div.activity ul.activity-list").append(response.contents);
	
			$parent.hide();
		}, 'json' );
		
		return false;
	});
}
</script>				</div><!-- .activity -->
	
					
			</div><!-- #content -->
		</div><!-- #container -->
		


<div class="clear"></div>
<br>
<div class="clear"></div>

<h3 class="sectionTitle"><cufon style="width: 56px; height: 13px;" alt="Recent " class="cufon cufon-canvas"><canvas style="width: 67px; height: 14px; top: 0px; left: -1px;" height="14" width="67"></canvas>
<cufontext>Recent </cufontext></cufon><cufon style="width: 43px; height: 13px;" alt="Posts" class="cufon cufon-canvas"><canvas style="width: 50px; height: 14px; top: 0px; left: -1px;" height="14" width="50"></canvas>
<cufontext>Posts</cufontext></cufon></h3>
<div class="clear"></div>


<section class="content-post-list">
	<ol class="posts-list hfeed">
	
	
		<li class="post-item clearfix">
			<article id="post-534" class="post-534 post type-post status-publish format-standard hentry category-news ">
				<div class="item-container">
				
										<div class="the-post-image">
													<a href="#/blog/2011/04/13/you-think-water-moves-fast/" rel="bookmark" title="Permalink to You think water moves fast?">
													<figure>
								<img src="images/sample-image-14-cropped-607x160.jpg" height="160" width="607">
							</figure>
						</a>
					</div>
										
					<div class="the-post-content">
						<header class="entry-header">
							
															<div class="author-avatar">
									<a href="#/blog/author/admin/"><img src="images/957bad97e787291fd5c2fae3b0deed0b-bpfull-35x35.jpg" alt="admin" height="35" width="35"></a>
								</div>
															
							<!-- Title / Page Headline -->
							<h2 class="entry-title"><a href="#/blog/2011/04/13/you-think-water-moves-fast/" rel="bookmark" title="Permalink to You think water moves fast?"><cufon style="width: 42px; height: 20px;" alt="You " class="cufon cufon-canvas"><canvas style="width: 59px; height: 21px; top: 1px; left: -2px;" height="21" width="59"></canvas>
							<cufontext>You </cufontext></cufon><cufon style="width: 55px; height: 20px;" alt="think " class="cufon cufon-canvas"><canvas style="width: 72px; height: 21px; top: 1px; left: -2px;" height="21" width="72"></canvas>
							<cufontext>think </cufontext></cufon><cufon style="width: 61px; height: 20px;" alt="water " class="cufon cufon-canvas"><canvas style="width: 78px; height: 21px; top: 1px; left: -2px;" height="21" width="78"></canvas>
							<cufontext>water </cufontext></cufon><cufon style="width: 69px; height: 20px;" alt="moves " class="cufon cufon-canvas"><canvas style="width: 86px; height: 21px; top: 1px; left: -2px;" height="21" width="86"></canvas>
							<cufontext>moves </cufontext></cufon><cufon style="width: 45px; height: 20px;" alt="fast?" class="cufon cufon-canvas"><canvas style="width: 59px; height: 21px; top: 1px; left: -2px;" height="21" width="59"></canvas>
							<cufontext>fast?</cufontext></cufon></a></h2>
							
														<div class="post-header-info clearfix">
																	<address class="vcard author">
										by <a href="#/blog/author/admin/" title="Posts by admin" rel="author">admin</a> 
									</address>
																	<span class="comments-link"><a href="#/blog/2011/04/13/you-think-water-moves-fast/#comments" title="Comment on You think water moves fast?">6</a></span>
																			<div class="cat-links">
											 <span class="meta-sep">|</span> <a href="#/blog/category/news/" title="View all posts in News" rel="category tag">News</a>										</div>
																			<abbr class="published" title="2011-04-13T05:01:26+00:00"><span class="entry-date">April 13, 2011</span></abbr>
																</div>
														
						</header>
						
						<!-- Content -->
						<div class="entry-content">
							You should see ice. It moves like it has a mind. Like it knows it
 killed the world once and got a taste for murder. After the avalanche, 
it took us a week to climb out....<div class="read-more"><a href="#/blog/2011/04/13/you-think-water-moves-fast/" title="Read more..." class="read-more-link">Read more...</a></div>						</div><!-- END .entry-content -->
			
						<!-- Post Footer -->
						<footer class="post-footer-info">
													</footer><!-- END .post-footer-info -->
					</div>
		
				</div>
			</article>
		</li>
		
		
		<li class="post-item clearfix">
			<article id="post-524" class="post-524 post type-post status-publish format-standard hentry category-community category-news ">
				<div class="item-container">
				
										<div class="the-post-image">
													<a href="#/blog/2011/03/19/airspeed-velocity-of-a-swallow/" rel="bookmark" title="Permalink to The Lysine Contingency">
													<figure>
								<img src="images/sample-image-7-cropped-607x160.jpg" height="160" width="607">
							</figure>
						</a>
					</div>
										
					<div class="the-post-content">
						<header class="entry-header">
							
															<div class="author-avatar">
									<a href="#/blog/author/admin/"><img src="images/957bad97e787291fd5c2fae3b0deed0b-bpfull-35x35.jpg" alt="admin" height="35" width="35"></a>
								</div>
															
							<!-- Title / Page Headline -->
							<h2 class="entry-title"><a href="#/blog/2011/03/19/airspeed-velocity-of-a-swallow/" rel="bookmark" title="Permalink to The Lysine Contingency"><cufon style="width: 42px; height: 20px;" alt="The " class="cufon cufon-canvas"><canvas style="width: 59px; height: 21px; top: 1px; left: -2px;" height="21" width="59"></canvas>
							<cufontext>The </cufontext></cufon><cufon style="width: 67px; height: 20px;" alt="Lysine " class="cufon cufon-canvas"><canvas style="width: 84px; height: 21px; top: 1px; left: -2px;" height="21" width="84"></canvas>
							<cufontext>Lysine </cufontext></cufon><cufon style="width: 120px; height: 20px;" alt="Contingency" class="cufon cufon-canvas"><canvas style="width: 133px; height: 21px; top: 1px; left: -2px;" height="21" width="133"></canvas>
							<cufontext>Contingency</cufontext></cufon></a></h2>
							
														<div class="post-header-info clearfix">
																	<address class="vcard author">
										by <a href="#/blog/author/admin/" title="Posts by admin" rel="author">admin</a> 
									</address>
																	<span class="comments-link"><a href="#/blog/2011/03/19/airspeed-velocity-of-a-swallow/#comments" title="Comment on The Lysine Contingency">5</a></span>
																			<div class="cat-links">
											 <span class="meta-sep">|</span> <a href="#/blog/category/community/" title="View all posts in Community" rel="category tag">Community</a>, <a href="#/blog/category/news/" title="View all posts in News" rel="category tag">News</a>										</div>
																			<abbr class="published" title="2011-03-19T09:36:46+00:00"><span class="entry-date">March 19, 2011</span></abbr>
																</div>
														
						</header>
						
						<!-- Content -->
						<div class="entry-content">
							The lysine contingency – it’s intended to prevent the spread of 
the animals is case they ever got off the island. Dr. Wu inserted a gene
 that makes a single faulty enzyme in protein metabolism. The...<div class="read-more"><a href="#/blog/2011/03/19/airspeed-velocity-of-a-swallow/" title="Read more..." class="read-more-link">Read more...</a></div>						</div><!-- END .entry-content -->
			
						<!-- Post Footer -->
						<footer class="post-footer-info">
													</footer><!-- END .post-footer-info -->
					</div>
		
				</div>
			</article>
		</li>
		
			
	</ol>
</section>



 </div></div></div> <!-- END id=home-page-layout_c2_col-2-3_1 class=col-2-3 -->
	<div id="home-page-layout_c2_col-1-3_2" class="col-1-3 clearfix last"><div class="i0 ugc"><div id="bp_groups_widget-3" class="widget scg_widget home-page widget_bp_groups_widget"><h4 class="widgetTitle"><cufon style="width: 57px; height: 13px;" alt="Groups" class="cufon cufon-canvas"><canvas style="width: 64px; height: 14px; top: 0px; left: -1px;" height="14" width="64"></canvas>
	<cufontext>Tests</cufontext></cufon></h4>
					<div class="item-options" id="groups-list-options">
				<a href="#/groups" id="newest-groups">Newest</a> <!--|
				<a href="#/groups" id="recently-active-groups" class="selected">Active</a> |
				<a href="#/groups" id="popular-groups">Popular</a>-->
			</div>
<?php
								$query1="SELECT `mst_subject`.`sub_name`, `mst_test`.`test_name`, `mst_test`.`total_que` FROM `mst_test` INNER JOIN `mst_subject` ON `mst_test`.`sub_id`=`mst_subject`.`sub_id` ORDER BY  `test_id` DESC LIMIT 3";
								$r_1=mysql_query($query1);
								while ($row1=mysql_fetch_row($r_1))
								{?>
			<ul id="groups-list" class="item-list">
									<li class="hoverable">
						<div class="item-avatar">
							<img src="images/f506ded6fbcec65e2d9422b35eaff3a9-bpthumb.jpg" alt="<?php echo $row1['1'];  ?>" class="avatar group-1-avatar" title="<?php echo $row1['1'];  ?>" height="35" width="35">
						</div>

							
						<div class="item">
							<div class="item-title">
                            <cufontext><?php echo $row1['1'];  ?></cufontext></cufon><cufon style="width: 28px; height: 16px;" class="cufon cufon-canvas"><canvas style="width: 42px; height: 17px; top: 1px; left: -1px;" height="17" width="42"></canvas>
							</div>
							<div class="item-meta">
								<span class="activity">
								subject: <?php echo $row1['0'];  ?>, questions: <?php echo $row1['2'];  ?>						</span>
							</div>
						</div>
					</li>
                    
				<?php }?>
									<!--<li class="hoverable">
						<div class="item-avatar">
							<a href="#/groups/wordpress-developers/" title="WordPress Developers"><img src="images/a1df409559c1c36b26a026e637c28e74-bpthumb.jpg" alt="Group logo of WordPress Developers" class="avatar group-2-avatar" title="WordPress Developers" height="35" width="35"></a>
						</div>

						<div class="item">
							<div class="item-title"><a href="#/groups/wordpress-developers/" title="WordPress Developers"><cufon style="width: 89px; height: 16px;" alt="WordPress " class="cufon cufon-canvas"><canvas style="width: 103px; height: 17px; top: 1px; left: -1px;" height="17" width="103"></canvas>
							<cufontext>WordPress </cufontext></cufon><cufon style="width: 89px; height: 16px;" alt="Developers" class="cufon cufon-canvas"><canvas style="width: 99px; height: 17px; top: 1px; left: -1px;" height="17" width="99"></canvas>
							<cufontext>Developers</cufontext></cufon></a></div>
							<div class="item-meta">
								<span class="activity">
								active 1 year, 8 months ago								</span>
							</div>
						</div>
					</li>

									<li class="hoverable">
						<div class="item-avatar">
							<a href="#/groups/web-experts/" title="Web Experts"><img src="images/d836853b3486ca4021867a0537351dcb-bpthumb.jpg" alt="Group logo of Web Experts" class="avatar group-41-avatar" title="Web Experts" height="35" width="35"></a>
						</div>

						<div class="item">
							<div class="item-title"><a href="#/groups/web-experts/" title="Web Experts"><cufon style="width: 40px; height: 16px;" alt="Web " class="cufon cufon-canvas"><canvas style="width: 54px; height: 17px; top: 1px; left: -1px;" height="17" width="54"></canvas>
							<cufontext>Web </cufontext></cufon><cufon style="width: 59px; height: 16px;" alt="Experts" class="cufon cufon-canvas"><canvas style="width: 69px; height: 17px; top: 1px; left: -1px;" height="17" width="69"></canvas>
							<cufontext>Experts</cufontext></cufon></a></div>
							<div class="item-meta">
								<span class="activity">
								active 1 year, 8 months ago								</span>
							</div>
						</div>
					</li>
-->
							</ul>
			<!--<input id="_wpnonce-groups" name="_wpnonce-groups" value="86e4c6523f" type="hidden"><input name="_wp_http_referer" value="/themes/salutation-wp/" type="hidden">			<input name="groups_widget_max" id="groups_widget_max" value="4" type="hidden">-->

		
		</div>	<div id="bp_core_members_widget-3" class="widget scg_widget home-page widget_bp_core_members_widget"><h4 class="widgetTitle"><cufon style="width: 67px; height: 13px;" alt="Members" class="cufon cufon-canvas"><canvas style="width: 75px; height: 14px; top: 0px; left: -1px;" height="14" width="75"></canvas>
		<cufontext>Members</cufontext></cufon></h4>
					<div class="item-options" id="members-list-options">
				<a href="#/members" id="newest-members">Top Scorer</a>
				<!--|  <a href="#/members" id="recently-active-members" class="selected">Active</a>

				
					| <a href="#/members" id="popular-members">Popular</a>
-->
							</div>
<?php
								$query1="SELECT DISTINCT `answer`.`level`, `answer`.`test_name`, `mst_user`.`institute`, `mst_user`.`name` FROM `answer` INNER JOIN `mst_user`ON `answer`.`user_id`= `mst_user`.`user_id` ORDER BY `level` DESC LIMIT 5";
								$r_1=mysql_query($query1);
								while ($row1=mysql_fetch_row($r_1))
								{?>
			<ul id="members-list" class="item-list">
									<li class="vcard hoverable">
						<div class="item-avatar">
							<a href="#/members/admin/" title="<?php echo $row1['3'];  ?>"><img src="images/957bad97e787291fd5c2fae3b0deed0b-bpthumb.jpg" alt="Profile picture of <?php echo $row1['3'];  ?>" class="avatar user-1-avatar" title="admin" height="35" width="35"></a>
						</div>

						<div class="item">
							<div class="item-title fn"><a href="#/members/admin/" title="<?php echo $row1['3'];  ?>"> <?php echo $row1['3'];  ?> </a></div>
							<div class="item-meta">
                            <span class="activity">
								Institute: <?php echo $row1['2'];  ?></span><br>
								<span class="activity">
								Test: <?php echo $row1['1'];  ?>, Max Level: <?php echo $row1['0'];  ?>							</span>
							</div>
						</div>
					</li> <?php }?>

									<!--<li class="vcard hoverable">
						<div class="item-avatar">
							<a href="#/members/sweetbro/" title="Sweet Bro"><img src="images/e5bca66a33145106b840dfb692b381f5-bpthumb.jpg" alt="Profile picture of Sweet Bro" class="avatar user-620-avatar" title="Sweet Bro" height="35" width="35"></a>
						</div>

						<div class="item">
							<div class="item-title fn"><a href="#/members/sweetbro/" title="Sweet Bro"><cufon style="width: 52px; height: 16px;" alt="Sweet " class="cufon cufon-canvas"><canvas style="width: 66px; height: 17px; top: 1px; left: -1px;" height="17" width="66"></canvas>
							<cufontext>Sweet </cufontext></cufon><cufon style="width: 28px; height: 16px;" alt="Bro" class="cufon cufon-canvas"><canvas style="width: 36px; height: 17px; top: 1px; left: -1px;" height="17" width="36"></canvas>
							<cufontext>Bro</cufontext></cufon></a></div>
							<div class="item-meta">
								<span class="activity">
								active 1 year, 8 months ago								</span>
							</div>
						</div>
					</li>

									<li class="vcard hoverable">
						<div class="item-avatar">
							<a href="#/members/kissbaby2012/" title="Nathaniel Richards"><img src="images/94cd033411ea090dd244eb81376e4f6e.png" alt="Profile picture of Nathaniel Richards" class="avatar user-527-avatar" title="Nathaniel Richards" height="35" width="35"></a>
						</div>

						<div class="item">
							<div class="item-title fn"><a href="#/members/kissbaby2012/" title="Nathaniel Richards"><cufon style="width: 81px; height: 16px;" alt="Nathaniel " class="cufon cufon-canvas"><canvas style="width: 95px; height: 17px; top: 1px; left: -1px;" height="17" width="95"></canvas>
							<cufontext>Nathaniel </cufontext></cufon><cufon style="width: 68px; height: 16px;" alt="Richards" class="cufon cufon-canvas"><canvas style="width: 78px; height: 17px; top: 1px; left: -1px;" height="17" width="78"></canvas>
							<cufontext>Richards</cufontext></cufon></a></div>
							<div class="item-meta">
								<span class="activity">
								active 1 year, 8 months ago								</span>
							</div>
						</div>
					</li>-->

									<!--<li class="vcard hoverable">
						<div class="item-avatar">
							<a href="#/members/hellopeeps/" title="Daniel"><img src="images/da09530c805448980087dc721d652d2c-bpthumb.jpg" alt="Profile picture of Daniel" class="avatar user-435-avatar" title="Daniel" height="35" width="35"></a>
						</div>

						<div class="item">
							<div class="item-title fn"><a href="#/members/hellopeeps/" title="Daniel"><cufon style="width: 50px; height: 16px;" alt="Daniel" class="cufon cufon-canvas"><canvas style="width: 64px; height: 17px; top: 1px; left: -1px;" height="17" width="64"></canvas>
							<cufontext>Daniel</cufontext></cufon></a></div>
							<div class="item-meta">
								<span class="activity">
								active 1 year, 8 months ago								</span>
							</div>
						</div>
					</li>

									<li class="vcard hoverable">
						<div class="item-avatar">
							<a href="#/members/caddomoney/" title="Andrew Money"><img src="images/3482778f13b2eb556e0f3fabc25eb337.jpg" alt="Profile picture of Andrew Money" class="avatar user-624-avatar" title="Andrew Money" height="35" width="35"></a>
						</div>

						<div class="item">
							<div class="item-title fn"><a href="#/members/caddomoney/" title="Andrew Money"><cufon style="width: 65px; height: 16px;" alt="Andrew " class="cufon cufon-canvas"><canvas style="width: 79px; height: 17px; top: 1px; left: -1px;" height="17" width="79"></canvas>
							<cufontext>Andrew </cufontext></cufon><cufon style="width: 54px; height: 16px;" alt="Money" class="cufon cufon-canvas"><canvas style="width: 64px; height: 17px; top: 1px; left: -1px;" height="17" width="64"></canvas>
							<cufontext>Money</cufontext></cufon></a></div>
							<div class="item-meta">
								<span class="activity">
								active 1 year, 8 months ago								</span>
							</div>
						</div>
					</li>-->

							</ul>
			<!--<input id="_wpnonce-members" name="_wpnonce-members" value="4557ba73ec" type="hidden"><input name="_wp_http_referer" value="/themes/salutation-wp/" type="hidden">			<input name="members_widget_max" id="members_widget_max" value="5" type="hidden">-->

		
		</div>	<div id="bp_core_recently_active_widget-3" class="widget scg_widget home-page widget_bp_core_recently_active_widget"><h4 class="widgetTitle"><cufon style="width: 71px; height: 13px;" alt="Recently " class="cufon cufon-canvas"><canvas style="width: 82px; height: 14px; top: 0px; left: -1px;" height="14" width="82"></canvas>
		<cufontext>Recently </cufontext></cufon><cufon style="width: 47px; height: 13px;" alt="Active" class="cufon cufon-canvas"><canvas style="width: 54px; height: 14px; top: 0px; left: -1px;" height="14" width="54"></canvas>
		<cufontext>Active</cufontext></cufon></h4>
					<div class="avatar-block">
									<div class="item-avatar">
						<a href="#/members/admin/" title="admin"><img src="images/957bad97e787291fd5c2fae3b0deed0b-bpthumb.jpg" alt="Profile picture of admin" class="avatar user-1-avatar" title="admin" height="35" width="35"></a>
					</div>
									<div class="item-avatar">
						<a href="#/members/sweetbro/" title="Sweet Bro"><img src="images/e5bca66a33145106b840dfb692b381f5-bpthumb.jpg" alt="Profile picture of Sweet Bro" class="avatar user-620-avatar" title="Sweet Bro" height="35" width="35"></a>
					</div>
									<div class="item-avatar">
						<a href="#/members/kissbaby2012/" title="Nathaniel Richards"><img src="images/94cd033411ea090dd244eb81376e4f6e.png" alt="Profile picture of Nathaniel Richards" class="avatar user-527-avatar" title="Nathaniel Richards" height="35" width="35"></a>
					</div>
									<div class="item-avatar">
						<a href="#/members/hellopeeps/" title="Daniel"><img src="images/da09530c805448980087dc721d652d2c-bpthumb.jpg" alt="Profile picture of Daniel" class="avatar user-435-avatar" title="Daniel" height="35" width="35"></a>
					</div>
									<div class="item-avatar">
						<a href="#/members/caddomoney/" title="Andrew Money"><img src="images/3482778f13b2eb556e0f3fabc25eb337.jpg" alt="Profile picture of Andrew Money" class="avatar user-624-avatar" title="Andrew Money" height="35" width="35"></a>
					</div>
									<div class="item-avatar">
						<a href="#/members/pepe/" title="pepeluis"><img src="images/384f13e850c74fe06c7eecebbdb5f96e.png" alt="Profile picture of pepeluis" class="avatar user-623-avatar" title="pepeluis" height="35" width="35"></a>
					</div>
									<div class="item-avatar">
						<a href="#/members/yogamatt/" title="Matt Caron"><img src="images/67e6a9746737164823ab9288f76a76a3.jpg" alt="Profile picture of Matt Caron" class="avatar user-457-avatar" title="Matt Caron" height="35" width="35"></a>
					</div>
									<div class="item-avatar">
						<a href="#/members/supertest/" title="Steve"><img src="images/d8718d707212398eda282b9a5754b4ac.png" alt="Profile picture of Steve" class="avatar user-192-avatar" title="Steve" height="35" width="35"></a>
					</div>
									<div class="item-avatar">
						<a href="#/members/nyyuniverse/" title="nyyuniverse"><img src="images/c9ca2b8a54f1b859767a3cd908a479a2-bpthumb.jpg" alt="Profile picture of nyyuniverse" class="avatar user-614-avatar" title="nyyuniverse" height="35" width="35"></a>
					</div>
									<div class="item-avatar">
						<a href="#/members/kirk/" title="Kirk"><img src="images/407e19b555c034df369a081311a3115a.png" alt="Profile picture of Kirk" class="avatar user-615-avatar" title="Kirk" height="35" width="35"></a>
					</div>
									<div class="item-avatar">
						<a href="#/members/altravista/" title="Altravista"><img src="images/f73bf797fd695e388c9ebea8b3efb9f7-bpthumb.jpg" alt="Profile picture of Altravista" class="avatar user-319-avatar" title="Altravista" height="35" width="35"></a>
					</div>
									<div class="item-avatar">
						<a href="#/members/jack7/" title="Jack"><img src="images/31ba3e07799ad51f972424e27e680c2f-bpthumb.jpg" alt="Profile picture of Jack" class="avatar user-53-avatar" title="Jack" height="35" width="35"></a>
					</div>
									<div class="item-avatar">
						<a href="#/members/gasafp/" title="Geraldo Augusto"><img src="images/9668e640d29a12855012ac990e6e9682.png" alt="Profile picture of Geraldo Augusto" class="avatar user-613-avatar" title="Geraldo Augusto" height="35" width="35"></a>
					</div>
									<div class="item-avatar">
						<a href="#/members/heovespa/" title="Heo Vespa"><img src="images/2991c9f99e06b09bec71cafd168a40ea.jpg" alt="Profile picture of Heo Vespa" class="avatar user-612-avatar" title="Heo Vespa" height="35" width="35"></a>
					</div>
									<div class="item-avatar">
						<a href="#/members/testuser/" title="IdealDesigner"><img src="images/257d77f975359ce5b74b13163b4dfabf-bpthumb.jpg" alt="Profile picture of IdealDesigner" class="avatar user-12-avatar" title="IdealDesigner" height="35" width="35"></a>
					</div>
							</div>
		
		</div>	<div id="text-16" class="widget scg_widget home-page widget_text"><h4 class="widgetTitle"><cufon style="width: 52px; height: 13px;" alt="About " class="cufon cufon-canvas"><canvas style="width: 63px; height: 14px; top: 0px; left: -1px;" height="14" width="63"></canvas>
		<cufontext>About </cufontext></cufon><cufon style="width: 30px; height: 13px;" alt="the " class="cufon cufon-canvas"><canvas style="width: 41px; height: 14px; top: 0px; left: -1px;" height="14" width="41"></canvas>
		<cufontext>the </cufontext></cufon><cufon style="width: 47px; height: 13px;" alt="Theme" class="cufon cufon-canvas"><canvas style="width: 54px; height: 14px; top: 0px; left: -1px;" height="14" width="54"></canvas>
		<cufontext>Theme</cufontext></cufon></h4>			<div class="textwidget"><p>Salutation
 is a premium WordPress theme built with web standards such as HTML5, 
CSS3. The theme is BuddyPress ready for your organization to create its 
own social network or community .</p>

<div class="clear"></div><br><br>

<div class="fromShortcode"><div class="staticBlockWrapper ugc" style="background: transparent;"><div class="staticContent scid-2463"><div class="col-1-2"> <div id="nav_menu-5" class="widget scg_widget 2-column-nav-left widget_nav_menu"><h4 class="widgetTitle"><cufon style="width: 79px; height: 13px;" alt="Resources" class="cufon cufon-canvas"><canvas style="width: 86px; height: 14px; top: 0px; left: -1px;" height="14" width="86"></canvas>
<cufontext>Resources</cufontext></cufon></h4><div class="menu-sample-pages-container"><ul id="menu-sample-pages" class="menu"><li id="menu-item-1931" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1931"><a href="#/blog/">Blog Post List</a></li>
<li id="menu-item-17" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-17"><a href="#/blog/2011/04/13/you-think-water-moves-fast/">Single Blog Post</a></li>
<li id="menu-item-1844" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1844"><a href="#/portfolio/">Portfolio – Images</a></li>
<li id="menu-item-1843" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1843"><a href="#/portfolio/video-portfolio/">Portfolio – Video</a></li>
<li id="menu-item-1845" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1845"><a href="#/portfolio/gallery/">Gallery Sample</a></li>
<li id="menu-item-1846" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1846"><a href="#/contact/">Contact Form</a></li>
</ul></div></div> </div>
<div class="col-1-2 last"> <div id="nav_menu-6" class="widget scg_widget 2-column-nav-right widget_nav_menu"><h4 class="widgetTitle"><cufon style="width: 87px; height: 13px;" alt="Community" class="cufon cufon-canvas"><canvas style="width: 94px; height: 14px; top: 0px; left: -1px;" height="14" width="94"></canvas>
<cufontext>Community</cufontext></cufon></h4><div class="menu-community-container"><ul id="menu-community" class="menu"><li id="menu-item-2830" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2830"><a href="#/activity/">Activity Stream</a></li>
<li id="menu-item-2831" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2831"><a href="#/members/">Members List</a></li>
<li id="menu-item-2832" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2832"><a href="#/groups/">Groups List</a></li>
<li id="menu-item-2833" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2833"><a href="#/forums/">Forums</a></li>
<li id="menu-item-2834" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2834"><a href="#/blogs/">Blogs Listing</a></li>
<li id="menu-item-2835" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2835"><a href="#/register/">Register</a></li>
</ul></div></div> </div><div class="clear"></div></div></div></div></div>
		</div></div></div> <!-- END id=home-page-layout_c2_col-1-3_2 class=col-1-3 -->
</div> <!-- END id=home-page-layout_container_2 -->

			
				</div>
			</div>
		</div> <!--! end of .pageWrapper -->
	</div> <!--! end of #Middle -->
	
	<div style="opacity: 1;" id="Bottom">		

		<footer style="background: transparent;">
	<div style="background-image: none; background-color: rgb(65, 75, 82); color: rgb(255, 255, 255);" id="BottomInner" class="pageWrapper theContent clearfix">
		<div class="inner-1">
			<div class="inner-2">
									<div class="ugc clearfix">
						<div class="staticBlockWrapper ugc" style="background: transparent;"><div class="staticContent scid-1710">
<div class="col-1-2">
<h3 class="sectionTitle"><cufon style="width: 52px; height: 13px;" alt="About " class="cufon cufon-canvas"><canvas style="width: 63px; height: 14px; top: 0px; left: -1px;" height="14" width="63"></canvas>
<cufontext>About </cufontext></cufon><cufon style="width: 30px; height: 13px;" alt="The " class="cufon cufon-canvas"><canvas style="width: 41px; height: 14px; top: 0px; left: -1px;" height="14" width="41"></canvas>
<cufontext>The </cufontext></cufon><cufon style="width: 47px; height: 13px;" alt="Theme" class="cufon cufon-canvas"><canvas style="width: 54px; height: 14px; top: 0px; left: -1px;" height="14" width="54"></canvas>
<cufontext>Theme</cufontext></cufon></h3>
<p><a href="#" title="Home">Salutation</a> is a premium WordPress theme created by <a href="#" title=" Website" target="_blank">Parallelus</a>
 . Developed using web 
standards such as HTML5, CSS3 and WordPress best practices. The theme is
 <a href="#" title=" Website" target="_blank">Press</a> ready with the necessary tools to create your own social network.</p>
</div>

<div class="col-1-4">
<h3 class="sectionTitle"><cufon style="width: 44px; height: 13px;" alt="What " class="cufon cufon-canvas"><canvas style="width: 55px; height: 14px; top: 0px; left: -1px;" height="14" width="55"></canvas>
<cufontext>What </cufontext></cufon><cufon style="width: 16px; height: 13px;" alt="is " class="cufon cufon-canvas"><canvas style="width: 27px; height: 14px; top: 0px; left: -1px;" height="14" width="27"></canvas>
<cufontext>is </cufontext></cufon><cufon style="width: 95px; height: 13px;" alt="BuddyPress?" class="cufon cufon-canvas"><canvas style="width: 104px; height: 14px; top: 0px; left: -1px;" height="14" width="104"></canvas>
<cufontext>BuddyPress?</cufontext></cufon></h3>
<p><a href="#" title="VisitWebsite" target="_blank">Press</a> is a <a href="http://wordpress.org/" title="Visit WordPress Website" target="_blank">WordPress</a> plugin to make your website a social network with community features like groups, forums, messaging, blogs and more.</p>
</div>

<div class="col-1-4 last">
<div>Follow us: <a oldtitle="Twitter" href="#" target="_blank" class="tip">Twitter</a> | <a oldtitle="Buzz" href="#" target="_blank" class="tip">Buzz</a> | <a oldtitle="Facebook" href="#" target="_blank" class="tip">Facebook</a></div>
</div>

<div class="clear"></div>

<div style="margin: 30px 0 0;">
<a href="" title="Parallelus Inc." target="_blank"><img src="images/logo-small-white.png" alt="Salutation - A Premium BuddyPress Theme" height="27" width="107"></a>
<p>Copyright © 2011 <a href="" title="Parallelus Inc." target="_blank">Parallelus</a>. All rights reserved.</p>
</div><div class="clear"></div></div></div>					</div>
							</div>
		</div>
	</div>
</footer>		
	</div> <!--! end of #Bottom -->
</div> <!--! end of #Wrapper -->


<div class="hidden">
	<div id="LoginPopup">
		<form class="loginForm" id="popupLoginForm" method="post" action="#/wp-login.php">
			<div id="loginBg"><div id="loginBgGraphic"></div></div>
			<div class="loginContainer">
				<h3><cufon style="width: 42px; height: 18px;" alt="Sign " class="cufon cufon-canvas"><canvas style="width: 58px; height: 19px; top: 1px; left: -1px;" height="19" width="58"></canvas>
				<cufontext>Sign </cufontext></cufon><cufon style="width: 22px; height: 18px;" alt="in " class="cufon cufon-canvas"><canvas style="width: 37px; height: 19px; top: 1px; left: -1px;" height="19" width="37"></canvas>
				<cufontext>in </cufontext></cufon><cufon style="width: 23px; height: 18px;" alt="to " class="cufon cufon-canvas"><canvas style="width: 39px; height: 19px; top: 1px; left: -1px;" height="19" width="39"></canvas>
				<cufontext>to </cufontext></cufon><cufon style="width: 45px; height: 18px;" alt="your " class="cufon cufon-canvas"><canvas style="width: 61px; height: 19px; top: 1px; left: -1px;" height="19" width="61"></canvas>
				<cufontext>your </cufontext></cufon><cufon style="width: 70px; height: 18px;" alt="account" class="cufon cufon-canvas"><canvas style="width: 84px; height: 19px; top: 1px; left: -1px;" height="19" width="84"></canvas>
				<cufontext>account</cufontext></cufon></h3>
				<fieldset class="formContent">
					<legend>Account Login</legend>
					<div class="fieldContainer">
						<label for="ModalUsername">User name</label>
						<input id="ModalUsername" name="log" class="textInput" type="text">
					</div>
					<div class="fieldContainer">
						<label for="ModalPassword">Passwoord</label>
						<input id="ModalPassword" name="pwd" class="textInput" type="password">
					</div>
				</fieldset>
			</div>
			<div class="formContent">
				<button type="submit" class="btn signInButton"><span>Sign in</span></button>
			</div>
          
			<div class="hr"></div>
			<div class="formContent">
				<a href="#/wp-login.php?action=lostpassword" id="popupLoginForgotPswd">Forgot your password?</a>
			</div>
		</form>
	</div>
</div>

<!-- Generated in 0.455 seconds. (117 q) -->

	<script type="text/javascript" src="index_files/jquery_002.js"></script>
<script type="text/javascript" src="index_files/jscolor.js"></script>
<script type="text/javascript" src="index_files/ddsmoothmenu.js"></script>
<script type="text/javascript" src="index_files/jquery.js"></script>
<script type="text/javascript" src="index_files/jquery_003.js"></script>
<div style="display: block; top: 222px;" id="ThemeStylePicker">
	<p>Top</p>
	<input value="CECCCC" style="background-color: rgb(206, 204, 204);" autocomplete="off" id="TopColorPicker" class="pickerInput">
	<p style="display:none;">Header</p>
	<input value="F2F0F0" autocomplete="off" id="HeaderColorPicker" class="pickerInput" style="display: none; background-color: rgb(242, 240, 240);">
	<p>Body</p>
	<input value="F2F0F0" style="background-color: rgb(242, 240, 240);" autocomplete="off" id="BodyColorPicker" class="pickerInput">
	<p>Middle</p>
	<input value="FAF9F9" style="background-color: rgb(250, 249, 249);" autocomplete="off" id="ContentColorPicker" class="pickerInput">
	<p>Footer</p>
	<input value="414B52" style="background-color: rgb(65, 75, 82);" autocomplete="off" id="FooterColorPicker" class="pickerInput">
	<a href="#" id="CloseThemeStylePicker">Close</a>
</div>
<script src="index_files/cufon.js"></script>
<script type="text/javascript">
	Cufon.replace
		('h1:not(.cta-title),h2:not(.cta-title),h3:not(.cta-title),h4:not(.cta-title),h5:not(.cta-title),h6:not(.cta-title)', {hover: true})
		('.widget .item-list .item-title', {hover: true });
	Cufon.now();
</script>

<script type="text/javascript">
		if ( jQuery('#MM ul') ) { ddsmoothmenu.init({ mainmenuid: "MM", orientation: "h", classname: "slideMenu", contentsource: "markup" }); }
	</script>
<script src="index_files/onLoad.js"></script>


</body></html>