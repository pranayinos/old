-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 23, 2013 at 10:27 AM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `try`
--

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE IF NOT EXISTS `data` (
  `st` varchar(5) DEFAULT NULL,
  `name_1` varchar(16) DEFAULT NULL,
  `name_2` varchar(16) DEFAULT NULL,
  `name_3` varchar(16) DEFAULT NULL,
  `addr` varchar(64) DEFAULT NULL,
  `city` varchar(24) DEFAULT NULL,
  `state` varchar(24) DEFAULT NULL,
  `ph_no` bigint(11) DEFAULT NULL,
  `id` varchar(56) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `photo` longblob NOT NULL,
  `imgname` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`st`, `name_1`, `name_2`, `name_3`, `addr`, `city`, `state`, `ph_no`, `id`, `pwd`, `photo`, `imgname`) VALUES
('Mr.', 'Ankit', 'Kumar', 'Sahu', 'Kata toli', 'Ranchi', 'jharkhand', 3218529752, 'ankit@gmail.com', '12345', 0x5265736f75726365206964202336, 'Small-office-design-ides.jpe.jpeg'),
('Mr.', 'Pranay', 'Kumar', 'Soni', 'Bara Bazar', 'hazaribag', 'Jharkhand', 9876543210, 'name@inos.in', 'qwerty', 0x5265736f75726365206964202336, 'Treasurer_SVM_Rajrappa.jpg'),
('Ms.', 'shashi', '', 'Kumari', 'baba path', 'hazaribag', 'jharkhand', 22658951, 'shashi.kr05@gmail.co', '0000', 0x5265736f75726365206964202336, 'Sec_SVM_Rajrappa.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `img`
--

CREATE TABLE IF NOT EXISTS `img` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pic` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `img`
--


-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `name` varchar(20) DEFAULT NULL,
  `pwd` varchar(16) DEFAULT NULL,
  `type` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`name`, `pwd`, `type`) VALUES
('name@inos.in', '123', NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
