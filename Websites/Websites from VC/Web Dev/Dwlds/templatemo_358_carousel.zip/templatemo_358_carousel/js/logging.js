$(document).ready(function(){

	$.get('http://download.templatemo.com/themes/log?id='+14171+'&oi='+12+'&ot=1&&url='+window.location, function(json){})    

});