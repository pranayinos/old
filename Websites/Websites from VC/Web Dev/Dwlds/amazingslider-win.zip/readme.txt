Amazing Slider
Version 1.6
Copyright 2013 Magic Hills Pty Ltd
http://amazingslider.com/


Overview
-----------------------------------------------------------------------

Amazing Slider is an easy-to-use Windows & Mac app for creating beautiful, professional, responsive jQuery Slider, Video Gallery and WordPress Slider Plugin.

What's New


Version 1.6
- Fix minor bugs

Version 1.5
- Support Vimeo
- Support standalone play/pause button
- Add an option of not croping thumbnail images
- Remember image and project folder
- Add options to specify folders for thumbnail images, lightbox images and skin images
- Support Joomla 1.5
- Add a button to apply web link options to all slides
- Fix a minor bug in lightbox effect
- Improve touch swipe for mobile and tablets

Version 1.4

- Add languages: German, Italian, Spanish, Japanese, French
- Export slider to Drupal module
- Support Joomla 3
- 5 new skins: Frongpage, Pink, RedAndBlack, Showcase, WoodBackground
- Add an option of not croping images when resizing
- Add an option to open current large size image and video in lightbox
- Add an option to add required top and bottom margin to slider
- Add an option to enable/disable touch swipe on mobile and tablet devices
- Add an option to customize the vertical position of navigation arrows
- Add an option to show number of slide in title
- Support ESC and ARROW keys in lightbox
- Web developer can now pass a URL parameter firstslideid to specify the first slide

Version 1.3

- Customize folders of images and JavaScript files when publishing
- Full unicode support
- Display license and project name in main window title
- Support navigation arrows on thumbnail carousel
- Support ribbon image on top of the slider
- Support vertical thumbnail carousel and navigation bullets
- Support title and description on thumbnail
- 7 new skins: Cube, Events, FeatureList, Highlight, Ribbon, Vertical, VerticalNumber
- Fix minor bugs

Version 1.2

- Fix a bug on Internet Explorer 6/7/8

Version 1.1

- Export jQuery Slideshow as Joomla module
- Fix minor bugs

Links
-----------------------------------------------------------------------

Download Free Versions for Windows and Mac:  http://amazingslider.com/downloads/
Online Examples:  http://amazingslider.com/examples/
Upgrade to Commercial Versions:  http://amazingslider.com/order/
Quick Start Guide:  http://amazingslider.com/help/
Contact Us: http://amazingslider.com/contact/