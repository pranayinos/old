var b_txt = '';

// write the badge
	
	
		 	 		
	b_txt+= '<td align="center" valign="center" style="padding:0" class="flickr_badge_image" id="flickr_badge_image1"><a href="http://www.flickr.com/photos/93382411@N07/8490922427/"><img src="http://farm9.staticflickr.com/8515/8490922427_c1a1a35818_s.jpg" alt="A photo on Flickr" title="8" height="75" width="75"></a></td>';
	
		 	 		
	b_txt+= '<td align="center" valign="center" style="padding:0" class="flickr_badge_image" id="flickr_badge_image2"><a href="http://www.flickr.com/photos/93382411@N07/8490919577/"><img src="http://farm9.staticflickr.com/8090/8490919577_afdf637fc6_s.jpg" alt="A photo on Flickr" title="7" height="75" width="75"></a></td>';
	
		 	 		
	b_txt+= '<td align="center" valign="center" style="padding:0" class="flickr_badge_image" id="flickr_badge_image3"><a href="http://www.flickr.com/photos/93382411@N07/8490912767/"><img src="http://farm9.staticflickr.com/8387/8490912767_2a8a4ce8e3_s.jpg" alt="A photo on Flickr" title="6" height="75" width="75"></a></td>';
	
		 	 		
	b_txt+= '<td align="center" valign="center" style="padding:0" class="flickr_badge_image" id="flickr_badge_image4"><a href="http://www.flickr.com/photos/93382411@N07/8492007572/"><img src="http://farm9.staticflickr.com/8385/8492007572_67c355afba_s.jpg" alt="A photo on Flickr" title="5" height="75" width="75"></a></td>';
	
		 	 		
	b_txt+= '<td align="center" valign="center" style="padding:0" class="flickr_badge_image" id="flickr_badge_image5"><a href="http://www.flickr.com/photos/93382411@N07/8492003654/"><img src="http://farm9.staticflickr.com/8511/8492003654_ce6ed3e18d_s.jpg" alt="A photo on Flickr" title="4" height="75" width="75"></a></td>';
	
		 	 		
	b_txt+= '<td align="center" valign="center" style="padding:0" class="flickr_badge_image" id="flickr_badge_image6"><a href="http://www.flickr.com/photos/93382411@N07/8490896907/"><img src="http://farm9.staticflickr.com/8241/8490896907_4eea752cdc_s.jpg" alt="A photo on Flickr" title="3" height="75" width="75"></a></td>';


b_txt += '<span style="position:absolute;left:-999em;top:-999em;visibility:hidden" class="flickr_badge_beacon"><img src="http://geo.yahoo.com/p?s=792600102&t=f2610b637a378ce4c227d593b12bf64b&r=http%3A%2F%2Fgsrthemes.com%2Faitynikon%2Flayout1%2Ffullwidth%2Findex.html&fl_ev=0&lang=en&intl=in" width="0" height="0" alt="" /></span>';

document.write(b_txt);