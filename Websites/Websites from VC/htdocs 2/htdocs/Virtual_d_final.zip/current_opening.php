<!DOCTYPE html>
<!--[if IE 7 ]>    <html lang="en-gb" class="isie ie7 oldie no-js"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en-gb" class="isie ie8 oldie no-js"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en-gb" class="isie ie9 no-js"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html class="no-js js" lang="en-gb"><!--<![endif]--><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>Virtual Concept . we are looking for  energetic and dynamic web professionals in php</title>
	
	<meta charset="utf-8">
	<meta name="keywords" content="">
	<meta name="description" content="">
    
    <!-- Favicon --> 
	<link rel="shortcut icon" href="http://www.virtualconcept.in/favicon.ico">
    
    <!-- this styles only adds some repairs on idevices  -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <!-- Google fonts - witch you want to use - (rest you can just remove) -->
    <link href="css/css.css" rel="stylesheet" type="text/css">
    
    <!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
    
    <!-- ######### CSS STYLES ######### -->
	
    <link rel="stylesheet" href="css/reset.css" type="text/css">
	<link rel="stylesheet" href="css/style.css" type="text/css">
    
    <!-- responsive devices styles -->
	<link rel="stylesheet" media="screen" href="css/responsive-leyouts.css" type="text/css">
    

<!-- just remove the below comments witch color skin you want to use -->
    <!--<link rel="stylesheet" href="styles/colors/lightblue.css" />-->
    <!--<link rel="stylesheet" href="styles/colors/lightgreen.css" />-->
    <!--<link rel="stylesheet" href="styles/colors/blue.css" />-->
    <!--<link rel="stylesheet" href="styles/colors/green.css" />-->
    <!--<link rel="stylesheet" href="styles/colors/red.css" />-->
    <!--<link rel="stylesheet" href="styles/colors/cyan.css" />-->
    <!--<link rel="stylesheet" href="styles/colors/purple.css" />-->
    <!--<link rel="stylesheet" href="styles/colors/yellow.css" />-->
    <!--<link rel="stylesheet" href="styles/colors/brown.css" />-->
    


<!-- just remove the below comments witch bg patterns you want to use -->
    
    <!--<link rel="stylesheet" href="styles/bg-patterns/pattern-default.css" />-->
    <!--<link rel="stylesheet" href="styles/bg-patterns/pattern-one.css" />-->
    <!--<link rel="stylesheet" href="styles/bg-patterns/pattern-two.css" />-->
    <!--<link rel="stylesheet" href="styles/bg-patterns/pattern-three.css" />-->
    <!--<link rel="stylesheet" href="styles/bg-patterns/pattern-four.css" />-->
    <!--<link rel="stylesheet" href="styles/bg-patterns/pattern-five.css" />-->
    <!--<link rel="stylesheet" href="styles/bg-patterns/pattern-six.css" />-->
    <!--<link rel="stylesheet" href="styles/bg-patterns/pattern-seven.css" />-->
    <!--<link rel="stylesheet" href="styles/bg-patterns/pattern-eight.css" />-->
    <!--<link rel="stylesheet" href="styles/bg-patterns/pattern-nine.css" />-->
    
    <!-- style switcher -->
    <link rel="stylesheet" media="screen" href="css/color-switcher.css">
    
    <!-- iosslider -->
	<link rel="stylesheet" media="screen" href="css/common.css">
    
    <!-- jquery jcarousel -->
    <link rel="stylesheet" type="text/css" href="css/skin.css">
    
    <!-- faqs -->
    <link rel="stylesheet" href="css/accordion.css" type="text/css" media="all">



    
<link type="text/css" rel="stylesheet" href="css/widget.css"><style type="text/css">#twtr-widget-1 .twtr-avatar { display: none; } #twtr-widget-1 .twtr-tweet-text { margin-left: 0; }</style></head>

<body class="bg-cover">

<div class="site_wrapper">
	
    <div class="container_full">
    
    <div class="top_contact_info">
    	<!--<div class="container">
        	<ul class="tci_list">
            	<li class="email"><a href="#">name@company.com</a></li>
                <li class="phone">1234-567-89000</li>
                <li><a href="#"><img src="current_opening_files/top_si1.jpg" alt=""></a></li>
                <li><a href="#"><img src="current_opening_files/top_si2.jpg" alt=""></a></li>
                <li><a href="#"><img src="current_opening_files/top_si3.jpg" alt=""></a></li>
                <li><a href="#"><img src="current_opening_files/top_si4.jpg" alt=""></a></li>
                <li><a href="#"><img src="current_opening_files/top_si5.jpg" alt=""></a></li>
                <li><a href="#"><img src="current_opening_files/top_si6.jpg" alt=""></a></li>
                <li><a href="#"><img src="current_opening_files/top_si7.jpg" alt=""></a></li>
                <li><a href="#"><img src="current_opening_files/top_si8.jpg" alt=""></a></li>
                <li><a href="#"><img src="current_opening_files/top_si9.jpg" alt=""></a></li>   
            </ul>
        </div>-->
    </div><!-- end top contact info -->
    	
        <div class="top_section">
    
    	<div class="container">

    		<div id="logo"><a href="index.php" class="site_logo"><!--<h1>Aity<i>nikon</i></h1><span class="logo_caption">clean, professional &amp; simple</span>--></a></div><!-- end logo -->
            	
               <nav id="access" class="access" role="navigation"> 
                <div id="menu" class="menu"> 
                    
                    <ul id="tiny">
                    
                        <li><a href="index.php">Home</a>
                        
							<!--<ul style="display: none; top: 68px; visibility: visible;">
                            	<li><a href="index-variation1">Home Variation 1</a></li>
                                <li><a href="index-variation2">Home Variation 2</a></li>
                                <li><a href="index-variation3">Home Variation 3</a></li>
                                <li><a href="index-variation4">Home Variation 4</a></li>
                                <li><a href="index-variation5">Home Variation 5</a></li>
							</ul>-->
                         </li>  
                        
                        <li><a href="about.php">Who We Are </a>
                        
                        	<!--<ul style="display: none; top: 68px; visibility: visible;">
                            	<li><a href="index">Header Style 1</a></li>
                                <li><a href="index">Header Style 2</a></li>
                                <li><a href="index">Header Style 3</a></li>
                                <li><a href="index">Header Style 4</a></li>
							</ul>-->
                        </li>
                        
                        <li><a href="services.php">Our Services</a>
                        
                        	<!--<ul style="display: none; top: 68px; visibility: visible;">
                            	<li><a href="index">Footer Style 1</a></li>
                                <li><a href="index">Footer Style 2</a></li>
                                <li><a href="index">Footer Style 3</a></li>
                                <li><a href="index">Footer Style 4</a></li>
							</ul>-->
                        </li>
                        
                        <li><a class="active.php" href="current_opening">Openings</a>
                        <!--
                        	<ul style="display: none; top: 68px; visibility: visible;">
                            	<li><a href="index-slider-1">Revolution Slider</a></li>
                                <li><a href="index-slider-2">Nivo Slider</a></li>
                                <li><a href="index">Thumbs Slider</a></li>
                                <li><a href="index-slider-3">Static Image</a></li>
                                <li><a href="index-slider-4">Video Slider</a></li>
							</ul>-->
                        </li>
                        
                        <li><a href="portfolio.php">Portfolio</a>
                        
                        	<!--<ul style="display: none; top: 68px; visibility: visible;">
                                <li><a href="elements">Elements</a></li>
                                <li><a href="typography">Typography</a></li>
                                <li><a href="pricing-tables">Pricing Tables</a></li>
                                <li><a href="columns">Page Columns</a></li>
                                <li><a href="testimonials">Testimonials</a></li>
                                <li><a href="faqs">FAQs</a></li>
                                <li><a href="tabs">Tabs</a></li>
                                <li><a href="#">Sample Third Leavel &nbsp;&gt;</a>
                                    <ul style="display: none; top: 0px; visibility: visible;">
                                        <li><a href="#">Third Leavel One</a></li>
                                        <li><a href="#">Third Leavel Two</a></li>
                                        <li><a href="#">Third Leavel Three</a></li>
                                    </ul>
                                </li>                             
                                <li><a href="#">Custom BG &amp; Colors</a></li>
                                <li><a href="#">PSD Files Included</a></li>                             
                                <li><a href="#">Clean &amp; Valid Code</a></li>
                            </ul>-->
                        </li>
                        
                        <!--<li><a href="#">Pages</a>
                        
                        	<ul style="display: none; top: 68px; visibility: visible;">
                                <li><a href="about">About Page Style 1</a></li>
                                <li><a href="about-2">About Page Style 2</a></li>
                                <li><a href="services">Services Style 1</a></li>
                                <li><a href="services-2">Services Style 2</a></li>
                                <li><a href="full-width">Full Width Page</a></li>
                                <li><a href="left-sidebar">Left Sidebar Page</a></li>
                                <li><a href="right-sidebar">Right Sidebar Page</a></li>
                                <li><a href="left-nav">Left Navigation</a></li>
                                <li><a href="right-nav">Right Navigation</a></li>
                                <li><a href="404">404 Error Page</a></li>
                            </ul>
                        </li>-->
                        
                       <!-- <li><a href="#">Portfolio</a>
                        
                        	<ul style="display: none; top: 68px; visibility: visible;">
                                <li><a href="portfolio-one">Single Image</a></li>
                                <li><a href="portfolio-two">2 Columns</a></li>
                                <li><a href="portfolio-three">3 Columns</a></li>
                                <li><a href="portfolio-four">4 Columns</a></li>
                            </ul>
                        </li>-->
                      <!--  
                        <li><a href="#">Blog</a>
                        
                            <ul style="display: none; top: 68px; visibility: visible;">
                            <li><a href="blog">with Large Image</a></li>
                            <li><a href="blog-2">with Small Image</a></li>
                            <li><a href="blog-post">Single Post</a></li>
                            </ul>
                        </li>-->
                        
                        <li><a href="contact.php">Contact Us</a>
                        
                        	<!--<ul style="display: none; top: 68px; visibility: visible;">
                            <li><a href="contact-2">Contact Style 1</a></li>
                            <li><a href="contact">Contact Style 2</a></li>
                            </ul>-->
                        </li>
                    </ul>
                </div>
                
          </nav>
                

		</div> 

	</div>
    
   <div class="top_shadow"></div><!-- end shadow -->

   </div><!-- end top -->



<!-- Content
======================================= --> 

<div class="page_title">

	<div class="container">
		<div class="leaft_title"><h1>Current Opening</h1></div>
        <div class="reght_pagenation"><a href="index.php">Home</a> <i>/</i>Current Opening <i>/</i></div>
	</div>
</div><!-- end page title -->   


<div class="container">


<!-- left sidebar starts -->
<div class="left_sidebar">

	<div class="sidebar_widget">
    	<h3>More About</h3>
		<ul class="arrows_list1">		
            <li><a href="about.php">Our History</a></li>
            <!--<li><a href="#">Professional Research</a></li>-->
            <li><a href="portfolio.php">Our Development</a></li>
            <li><a href="#">Partnership With Us</a></li>
            <li><a href="current_0pening.php">Company Carreer</a></li>
           <!-- <li><a href="#">New Technology</a></li>-->
            <li><a href="testimonials.php">Client Testimonials</a></li>
		</ul>
	</div><!-- end section -->
    
    <div class="clearfix mar_top3"></div>
    
    <!--<div class="sidebar_widget">
    
    	<h3>Recent Posts</h3>
        
			<ul class="recent_posts_list">
                
                <li>
                <span><a href="#"><img src="current_opening_files/post-simg1.jpg" alt=""></a></span>
                <a href="#">Publishing packag esanse web page editos</a>
                <i>May 09, 2013</i> 
                </li>
                
                <li>
                <span><a href="#"><img src="current_opening_files/post-simg2.jpg" alt=""></a></span>
                <a href="#">Sublishing packag esanse web page editos</a>
                <i>May 08, 2013</i> 
                </li>
                        
                <li class="last">
                <span><a href="#"><img src="current_opening_files/post-simg3.jpg" alt=""></a></span>
                <a href="#">Mublishing packag esanse web page editos</a>
                <i>May 07, 2013</i> 
                </li>

            </ul>
                
	</div>--><!-- end section -->
    
    <div class="clearfix mar_top3"></div>
    
    <!--<div class="clientsays_widget">
    
    	<h3>Happy Clients Say</h3>
        <img src="current_opening_files/site-img8.jpg" alt="">
<strong>- Henry Brodie</strong><p></p>  
                
	</div>--><!-- end section -->
    
    <div class="clearfix mar_top3"></div>
    
    <div class="sidebar_widget">
    
    	<h3>Portfolio Widget</h3>

		<div class="freash_works_gallery sidewid">
          <div class=" jcarousel-skin-tango"><div style="position: relative; display: block;" class="jcarousel-container jcarousel-container-horizontal"><div style="position: relative;" class="jcarousel-clip jcarousel-clip-horizontal"><ul style="overflow: hidden; position: relative; top: 0px; margin: 0px; padding: 0px; left: 0px; width: 1120px;" id="mycarousel" class="jcarousel-list jcarousel-list-horizontal">
            <li jcarouselindex="1" style="float: left; list-style: none outside none;" class="jcarousel-item jcarousel-item-horizontal jcarousel-item-1 jcarousel-item-1-horizontal">
            	<b></b><img src="images/virtual_concept_project1.png" alt="virtual_concept_project1">
                 <strong><a href="http://incrediblejharkhand.com" target="_blank">Incredible Jharkhand</a></strong>
				 
            </li>
            
            <li jcarouselindex="2" style="float: left; list-style: none outside none;" class="jcarousel-item jcarousel-item-horizontal jcarousel-item-2 jcarousel-item-2-horizontal">
            	<b></b><img src="images/virtual_concept_project2.png" alt="virtual_concept_project2">
                <strong><a href="http://www.chitraguptaparivar.com" target="_blank">Chitragupta Parivar</a></strong>
				<i>A Community to communicate</i>
            </li>
            
            <li jcarouselindex="3" style="float: left; list-style: none outside none;" class="jcarousel-item jcarousel-item-horizontal jcarousel-item-3 jcarousel-item-3-horizontal">
            	<b></b><img src="images/virtual_concept_project3.png" alt="virtual_concept_project3">
                <strong><a href="http://www.basiltree.in" target="_blank">Basil Tree</a></strong>
				<i>Italian Pizza Restaurant</i>
            </li>
            
            <li jcarouselindex="4" style="float: left; list-style: none outside none;" class="jcarousel-item jcarousel-item-horizontal jcarousel-item-4 jcarousel-item-4-horizontal">
            	<b></b><img src="images/virtual_concept_shambhavi.png" alt="Shambhavi Construction">
                <strong><a href="http://www.shambhaviconstruction.com" target="_blank">Shambhavi Construction</a></strong>
				 
            </li>

            
          </ul></div><div disabled="disabled" style="display: block;" class="jcarousel-prev jcarousel-prev-horizontal jcarousel-prev-disabled jcarousel-prev-disabled-horizontal"></div><div style="display: block;" class="jcarousel-next jcarousel-next-horizontal"></div></div></div>
          
          </div>

                
	</div><!-- end section -->
    
    
        <div class="clearfix mar_top3"></div>
    
    <!--<div class="sidebar_widget">
    
    	<h3>Text Widget</h3>
        
        <p></p>


                
	</div>--><!-- end section -->


	
</div><!-- end left sidebar -->



<div class="content_right">
    
    	<h2>We Build Smarter Highly Usable Stuff!</h2>
        
        <p>At Virtual Concept, we believe in offering much more than just a job. We strive to give you a full-fledged growing career.</p>
        
        <div class="clearfix mar_top2"></div>
        
        <div class="big_text1">we believe in offering much more than just a job. <i>We strive to give you a full-fledged growing career.</i>
 Energetic workplace environment & collaborative culture for long term career growth.  Towards this end we provide you with superior training and the opportunity to work in different industry and service practices on the <i>latest technology platforms</i>. We would like to describe our people and our workplace in simple terms but it isn't easy when what we are trying to describe is a certain feeling of joie de vivre; <i>a feeling of energy and vitality, of freshness, </i>of a place where people are unafraid to voice new ideas and where there is minimal hierarchy</div>
        
        <div class="clearfix divider_line3"></div>
       
       
       
        
        <h2>currently we are looking for</h2>
        	
            
            <ul class="lirt_section">
            	<li class="left">1</li>
                <li><strong>PHP/ MySQL Developer</strong> <i>Very good in PHP, MySQL, XHTML, Javascript, Ajax, Jquery, CSS. Customization of Wordpress, Drupal, Joomla, etc will be added advantage</i></li>
            </ul><!-- end section -->
            
            <div class="clearfix mar_top2"></div>
            
            <ul class="lirt_section">
            	<li class="left">2</li>
                <li><strong>Android Application Developer</strong> <i>Professional and sound knowledge of Android application development.</i></li>
            </ul><!-- end section -->
            
            <div class="clearfix mar_top2"></div>
            
            <ul class="lirt_section">
            	<li class="left">3</li>
                <li><strong>PHP/ MySQL Trainee</strong> <i>Solution oriented trainee for PHP, MySQL, Javascript, Ajax, HTML, CSS  web applications who are ready to work on challenging projects</i></li>
            </ul><!-- end section -->
            
            <!--<div class="clearfix mar_top2"></div>
            
            <ul class="lirt_section">
            	<li class="left">4</li>
                <li><strong>4 Layouts of Fullwidth and Boxed</strong> <i>Professional Website Design and Development Services and Fully Satisfied Customers Worldwide</i></li>
            </ul>--><!-- end section -->
            
            <!--<div class="clearfix mar_top2"></div>
            
            <ul class="lirt_section">
            	<li class="left">5</li>
                <li><strong>5 Different Awesome Slideshows. Include Slider Revolution worth of $12</strong> <i>Professional Website Design and Development Services and Fully Satisfied Customers Worldwide</i></li>
            </ul>--><!-- end section -->
            
            <!--<div class="clearfix mar_top2"></div>
            
            <ul class="lirt_section">
            	<li class="left">6</li>
                <li><strong>Custom BG Patterns, Unlimited Colors and Shortcodes</strong> <i>Professional Website Design and Development Services and Fully Satisfied Customers Worldwide</i></li>
            </ul>--><!-- end section -->
            
            <!--<div class="clearfix mar_top2"></div>
            
            <ul class="lirt_section">
            	<li class="left">7</li>
                <li><strong>5 Different Home page Versions</strong> <i>Professional Website Design and Development Services and Fully Satisfied Customers Worldwide</i></li>
            </ul>--><!-- end section -->
            
            <!--<div class="clearfix mar_top2"></div>
            
            <ul class="lirt_section">
            	<li class="left">8</li>
                <li><strong>Useful Typography Elements</strong> <i>Professional Website Design and Development Services and Fully Satisfied Customers Worldwide</i></li>
            </ul>--><!-- end section -->
            
            <!--<div class="clearfix mar_top2"></div>
            
            <ul class="lirt_section">
            	<li class="left">9</li>
                <li><strong>Cross Browser Support and Layered PSD Files</strong> <i>Professional Website Design and Development Services and Fully Satisfied Customers Worldwide</i></li>
            </ul>--><!-- end section -->

        
        	<!-- end more features section -->
        
        
        

</div><!-- end content left side area -->








</div>


<!-- Footer
======================================= -->

<div class="twitter_feed_full">

<div class="container">

	<div class="twitter_feed">
    
             <p><script src="current_opening_files/widget.js"></script>
                <script>
                new TWTR.Widget({
                  version: 2,
                  type: 'profile',
                  rpp: 1,
                  interval: 5000,
                  width: 900,
                  height: 70,
                  theme: {
                    shell: {
                      background: 'transparent',
                      color: '#000'
                    },
                    tweets: {
                      background: 'transparent',
                      color: '#999',
                      links: '#ff9900'
                    }
                  },
                  features: {
                    scrollbar: false,
                    loop: false,
                    live: false,
                    hashtags: true,
                    timestamp: true,
                    avatars: false,
                    behavior: 'all'
                  }
                }).render().setUser('gsrthemes9').start();
                </script></p><div class="twtr-widget twtr-widget-profile" id="twtr-widget-1"><div class="twtr-doc" style="width: 900px;">            <div class="twtr-hd"><a target="_blank" href="#" class="twtr-profile-img-anchor"><img alt="profile" class="twtr-profile-img" src="images/default_profile_3_normal.png"></a>                      <h3>Virtual Concept</h3>                      
                <h4><a target="_blank" href="#">(VC) Virtual Concept</a></h4>             
                </div>            <div class="twtr-bd">              <div class="twtr-timeline" style="height: auto;">                <div class="twtr-tweets">                  <div class="twtr-reference-tweet"></div><div class="twtr-tweet" id="tweet-id-1"><div class="twtr-tweet-wrap">         <div class="twtr-avatar">           <div class="twtr-img"><a target="_blank" href="#"><img alt="gsrthemes9 profile" src="images/default_profile_3_normal.png"></a></div>         </div>         <div class="twtr-tweet-text">           <p>Find us on Social Media             <a target="_blank" href="https://www.facebook.com/#!/pages/Virtual-Concept-Hardware-and-Software-Technology-Private-Limited/199888860036638" class="twtr-user">Facebook</a>---<a target="_blank" href="https://twitter.com/virtualconceptt" class="twtr-user">Twitter</a>---<a target="_blank" href="https://plus.google.com/105680967097938130098" class="twtr-user">Google Plus</a>---<a target="_blank" href="http://pinterest.com/virtualconcept/" class="twtr-user">Pinterest</a>---<a target="_blank" href="http://www.linkedin.com/company/virtual-concept-hardware-and-software-technology-p-limited" class="twtr-user">LinkedIn</a>                      </p>         </div>       </div></div>                  <!-- tweets show here -->                </div>              </div>            </div>            <div class="twtr-ft">              <div><a target="_blank" href="https://twitter.com/"><img alt="" src="images/widget-bird.png"></a>                <span><a target="_blank" class="twtr-join-conv" style="color:#000" href="https://twitter.com/gsrthemes9">Join the conversation</a></span>              </div>            </div>          </div></div>
            <p></p>
    
    </div>
	
    <div class="shadow_02"></div>

</div>

<div id="footer">

<div class="footer_columns">

	<div class="container">
    
        <div class="one_fourth">
        <div class="footer_logo"><a href="index.php" class="footer_logo">
            <h1><img src="images/footer_logo.jpg" alt="footer logo" width="150" height="50"></h1><span class="logo_caption">clean, professional &amp; simple</span></a></div>
            <ul class="address-liste">
            	<li class="icon1">Ground Floor, Shailza Apartment, Matwari<br>Hazaribagh, jharkhand, India 825301</li>
                <li class="icon2">+91 6546 270119</li>
                <li class="icon2">+91 9430143342, 9708167801, 9934153842</li>
                <li class="worldmap"></li>
            </ul>
        </div><!-- end address info -->
        
        <div class="one_fourth">
        	<h2>Useful links</h2>
                    <ul class="arrows_list1">		
            <li><a href="about.php">Our History</a></li>
            <!--<li><a href="#">Professional Research</a></li>-->
            <li><a href="portfolio.php">Our Development</a></li>
            <li><a href="#">Partnership With Us</a></li>
            <li><a href="current_0pening.php">Company Carreer</a></li>
           <!-- <li><a href="#">New Technology</a></li>-->
            <li><a href="testimonials.php">Client Testimonials</a></li>
		</ul>
             
            
        
        </div><!-- end section --> 
        
        <div class="one_fourth">
        	<h2>Get in touch</h2>
                	
                <ul class="socials-list">
                <li><a target="_blank" href="https://www.facebook.com/#!/pages/Virtual-Concept-Hardware-and-Software-Technology-Private-Limited/199888860036638" title="facebook"><img src="images/footer-socials-01.png" alt="">Connect with facebook</a></li>
                <li><a target="_blank" href="https://twitter.com/virtualconceptt" title="twitter"><img src="images/footer-socials-02.png" alt="">Follow on twitter</a></li>
                <li><a target="_blank" href="https://plus.google.com/105680967097938130098" title="google plus"><img src="images/footer-socials-03.png" alt="">Sharing on Google+</a></li>
     			<li><a target="_blank" href="http://www.linkedin.com/company/virtual-concept-hardware-and-software-technology-p-limited" title="you tube"><img src="images/footer-socials-04.png" alt="">Connect with linkedin</a></li>
                <li><a target="_blank" href="http://pinterest.com/virtualconcept/" title="linked in"><img src="images/footer-socials-05.png" alt="">Content sharing on Pinterest</a></li>
                <li><a href="#" title="linked in"><img src="images/footer-socials-06.png" alt="">Share videos on YouTube</a></li>
               <!-- <li><a href="#" title="rss"><img src="images/footer-socials-07.png" alt="">Subscribe rss feed</a></li>-->
                </ul>
        </div><!-- end social links --> 
        
        <div class="one_fourth last">
        	<h2>Flickr Photos</h2>
        	<div id="flickr_badge_wrapper">
            	<script type="text/javascript" src="js/badge_code_v2.js"></script> 
                <a href="http://www.flickr.com/photos/93382411@N07/8492007572/"><img src="description_files/8492007572_67c355afba_s.jpg" alt="A photo on Flickr" title="5" height="75" width="75"></a>
                <a href="http://www.flickr.com/photos/93382411@N07/8492003654/"><img src="description_files/8492003654_ce6ed3e18d_s.jpg" alt="A photo on Flickr" title="4" height="75" width="75"></a>
                <a href="http://www.flickr.com/photos/93382411@N07/8490896907/"><img src="description_files/8490896907_4eea752cdc_s.jpg" alt="A photo on Flickr" title="3" height="75" width="75"></a>
                <span style="position:absolute;left:-999em;top:-999em;visibility:hidden" class="flickr_badge_beacon"><img src="description_files/p.gif" alt="" height="0" width="0"></span>
            
            </div>
        
        </div><!-- end flickr --> 

</div>
  
</div><!-- end footer all columns --> 
 	
    
	<div class="copyright_info">
    
    	<div class="container">
        
    	<div class="one_half"><b>Copyright © 2013 (VC) Virtual Concept. All rights reserved</b></div>
		
        <div class="one_half last">
        	<span><a href="#">Terms of Service</a> | <a href="#">Privacy Policy</a></span>
                    
        </div>
        
		</div>
        
    </div><!-- end copyright info -->    

</div>


    
<!-- style switcher -->
<script type="text/javascript" src="current_opening_files/styleswitcher.js"></script>
<link rel="alternate stylesheet" type="text/css" href="css/lightblue.css" title="lightblue">
<link rel="alternate stylesheet" type="text/css" href="css/lightgreen.css" title="lightgreen">
<link rel="alternate stylesheet" type="text/css" href="css/blue.css" title="blue">
<link rel="alternate stylesheet" type="text/css" href="css/green.css" title="green">
<link rel="alternate stylesheet" type="text/css" href="css/red.css" title="red">
<link rel="alternate stylesheet" type="text/css" href="css/cyan.css" title="cyan">
<link rel="alternate stylesheet" type="text/css" href="css/purple.css" title="purple">
<link rel="alternate stylesheet" type="text/css" href="css/yellow.css" title="yellow">
<link rel="alternate stylesheet" type="text/css" href="css/brown.css" title="brown">

<div style="left: -204px;" id="style-selector">
    
    
</div>
</div>
</div><!-- end style switcher -->


<a style="display: inline;" href="#" class="scrollup">Scroll</a><!-- end scroll to top of the page-->
   
   

</div>

    
<!-- ######### JS FILES ######### -->
<!-- get jQuery from the google apis -->
<script type="text/javascript" src="current_opening_files/jquery_004.js"></script>

<!-- style switcher -->
<script src="current_opening_files/jquery-1_002.js"></script>
<script src="current_opening_files/styleselector.js"></script>

<!-- main menu -->
<script type="text/javascript" src="current_opening_files/ddsmoothmenu.js"></script>
<script type="text/javascript" src="current_opening_files/jquery-1.js"></script>
<script type="text/javascript" src="current_opening_files/selectnav.js"></script>

<!-- jquery jcarousel -->
<script type="text/javascript" src="current_opening_files/jquery_002.js"></script>

<!-- iosSlider plugin -->
<script src="current_opening_files/jquery_003.js"></script>
<script src="current_opening_files/jquery.js"></script>
<script src="current_opening_files/custom.js"></script>

<script type="text/javascript" src="current_opening_files/scripts.js"></script>


<!-- scroll up -->
<script type="text/javascript">
    $(document).ready(function(){
 
        $(window).scroll(function(){
            if ($(this).scrollTop() > 100) {
                $('.scrollup').fadeIn();
            } else {
                $('.scrollup').fadeOut();
            }
        });
 
        $('.scrollup').click(function(){
            $("html, body").animate({ scrollTop: 0 }, 500);
            return false;
        });
 
    });
</script>


<!-- jquery jcarousel -->
<script type="text/javascript">

	jQuery(document).ready(function() {
			jQuery('#mycarousel').jcarousel();
	});
	
	jQuery(document).ready(function() {
			jQuery('#mycarouseltwo').jcarousel();
	});
	
</script>

<script type="text/javascript" src="current_opening_files/custom_002.js"></script>



</body></html>