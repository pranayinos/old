<?php 
$res=mysql_connect("localhost","root","");
mysql_select_db("virtual",$res);
?>