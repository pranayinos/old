<div style="border: black; border-style: groove; height: 200px; width: 300px; padding-top: 5px;" >
<form >
<table width="300" cellspacing="5" style="height: 20px;">
<tr><th colspan="2" bgcolor="#FF8000" align="center">  User Login </th></tr>
<tr><td> &nbsp;&nbsp;Username </td><td align="center"><input  type="text" name="uname"/> &nbsp; &nbsp; </td></tr>
<tr><td> &nbsp;&nbsp;Password </td><td align="center"><input  type="password" name="upass"/> &nbsp; &nbsp; </td></tr>
<tr><td> &nbsp;&nbsp;Remember me </td><td align="center"><input  type="checkbox" name="rem" />(uncheck on public comp)</td></tr>
<tr><td colspan="2" align="center"><br /><input  type="submit" name="login" value="Log in"/></td></tr>
</table>
</form>
</div>
<?php




?>