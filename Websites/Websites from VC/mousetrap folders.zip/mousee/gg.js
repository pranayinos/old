<script type="text/javascript">
alert("Fuck");
<\script>
