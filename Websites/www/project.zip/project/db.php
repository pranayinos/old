<?php

 /**
 * @author pranay
 * @copyright 2011
 */
 $SERVER='localhost';
 $USER='root';
 $PASSWORD='';
 $DATABASE='ankit';

?>