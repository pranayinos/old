function validaPte()
{
    var uname=document.getElementById("uname").value;
    var upass=document.getElementById("upass").value;
    var chkbox=document.getElementById("uchkbox").value;    
    if (uname.length==0||upass.length==0)
    {
        alert("Username or Password cannot be left Blank");
        login=="false";
    }
}